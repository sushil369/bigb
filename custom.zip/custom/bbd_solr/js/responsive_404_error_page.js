/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


jQuery(document).ready(function() {
    var getWidth = jQuery(window).width();

    if (getWidth < 750) {
        jQuery('#content').empty();

        var appendHtml = '<div class="responsive-content"><p><b>Sorry, the page you are looking for could not be found</b></p><p><span>TIP:</span> Check your spelling or modify your search.</p></div>'
        jQuery('#content').append(appendHtml);
    }

});