(function ($) {
    Drupal.behaviors.auto_submit_ccavenue_form = {
        attach: function (context) {
            var pathname = window.location.pathname;
            if (pathname.indexOf("review") > 0) {
                $(document).ready(function () {
                    $('#commerce-checkout-form-review').submit();
                });
            }
            $(document).ready(function () {
                $("#ccavenue-payment-redirect-form").submit();
            });
        }
    };
})(jQuery);