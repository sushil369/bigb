(function ($) {
    $(document).ready(function () {
        $('select[name="sub_category"]').change(function () {
            jQuery('#custom-commission-form').submit();
        });
    });
})(jQuery);
 