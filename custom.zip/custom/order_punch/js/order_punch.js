/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


(function ($) {
    Drupal.behaviors.order_punch = {
        attach: function (context) {

            $('.field-name-field-remove-status').hide();

            $(document).ready(function (e) {
                //$('#edit-field-mobile-no').hide();
                //$('#edit-field-enter-email').hide();

                $('#edit-field-address-id').hide();
                $('#edit-field-franchisee-id').hide();
                $('#edit-field-customer-id').hide();
                $('#edit-field-enter-products-info-und-0-field-field-status').hide();
                $('.field-name-field-remove-status').hide();
                $('#edit-field-status').hide();
                $('#edit-field-remark').hide();
                $('#edit-field-updater-name').hide();
                $('#edit-field-order-id-punch').hide();


                if ($('#edit-field-email-und-0-value').val()) {
                    $('#edit-field-enter-products-info').show();
                }
                else {
                    $('#edit-field-enter-products-info').hide();
                }
                if ($('#edit-field-mobile-no-und-0-value').val()) {
                    $('#edit-field-mobile-no-und-0-value').trigger('blur');
                }
                $('#edit-field-mobile-no-und-0-value').blur(function () {
                    if ($('#edit-field-order-punch-pincode-und-0-value').val()) {
                        $('#edit-field-order-punch-pincode-und-0-value').blur();
                    }
                });
                $('#edit-field-order-punch-pincode-und-0-value').blur(function (e) {
                    if (!$('#edit-field-mobile-no-und-0-value').val()) {
                        alert('Please enter mobile number.');
                    }

                    //     if($("input.fluid table [id*='field-enter-products-info-values']").length > 0) { 
                    //    alert('hi');
                    //Exists, do something...
//}

                    var bs = window.location.pathname.split('/');
                    var mob = $('#edit-field-mobile-no-und-0-value').val();
                    //var ofs = $('#getdatamob').offset();
                    var pincode = $(this).val();
                    var arr = [];
                    var productqty = [];
                    var skuvalues = '';

                    if ($('#order-punch-submit-val').length > 0) {

                        $('.sticky-enabled tbody tr').each(function () {
                            var customerId = $(this).find("#order_punch_sku").html();
                            //skuvalues = {'sku' : customerId };
                            arr.push(customerId);
                            $("#efield-enter-products-info-values input.fluid").css("width", "450");
                            var productQuantity = $(this).find("#order_punch_qty").html();
                            productqty.push(productQuantity);
                        });
                    }

                    var path = Drupal.settings.basepath;

                    var uid = Drupal.settings.uid;
                    //    $("#order_punch_sku").css("width","450");
                    $.ajax({
                        url: path + '/getdata_bymob',
                        type: "POST",
                        data: "mob=" + mob + "&pincode=" + pincode,
                        success: function (data) {

                            if ($('#order_punch_address').length <= 0) {
                                //  $('div#edit-field-email').after('<div id="order_punch_address"></div>');
                                //edit-field-enter-products-info
                                $('div#edit-field-enter-products-info').after('<div id="order_punch_address"></div>');

                            }
                            else {
                                $('#order_punch_address').html('<div id="order_punch_address"></div>');
                            }

                            var details = jQuery.parseJSON(data);

                            if (details.noservice) {
                                $('#edit-email').val('');
                                alert(details.noservice);
                                e.preventDefault();
                            }
                            else if (details.skunoservice) {
                                $('#edit-email').val('');
                                alert(details.skunoservice);
                                e.preventDefault();
                            }

                            if (details.customerId == 'false') {
                                //var html = '<a href="'+path+'/admin/commerce/customer-profiles/add/shipping">Create Customer</a><br/>';
                                $('#edit-field-enter-products-info').hide();
                                $('#order_punch_address').html(html);
                            }
                            else {
                                var html = '<table> <tr>';
                                jQuery.each(details.address, function (index, value) {
                                    html += '<td><div class="address_order_punch"> <input type="radio" id="address" name="address" required value=' + index + '>' + value + '</div></td>';
                                });
                                html += '</tr><tr><a href= "' + path + '/user/' + details.uidofprofile + '/addressbook/billing/create' + '?ph=' + details.phonoofprofile + '&pi=' + details.pincodeofprofile + '">Add New Address</a></tr></table>';

                                $('#order_punch_address').html(html);
                                $('#edit-field-enter-products-info').show();
                                $('#edit-field-email-und-0-value').val(details.email);
                                $('#edit-field-customer-id-und-0-uid').val(details.customerId);
                                //alert(details.customerId);
                                //alert(uid);
                                $('#edit-field-franchisee-id-und-0-uid').val(uid);
                                $('#edit-field-enter-products-info-und-0-field-punch-pincode-und-0-value').val(pincode);
                                $(document).on('click', '#address', function () {
                                    $('#edit-field-address-id-und-0-value').val($(this).val());
                                });
                            }
                        }
                    });
                });
                $("input[id*='field-sku-und']").css("width", "450");
                $("input[id*='weight']").css("display", "none");
                // edit-field-enter-products-info-und-0-field-price-und-0-amount
                $("input[id*='field-sku-und']").blur(function (e) {
                    var path = Drupal.settings.basepath;
                    var skujq = $(this).val();
                    var currentId = $(this).attr('id');
                    var substr = currentId.split('-');
                    var curobject = substr[6];
                    //  edit-field-enter-products-info-und-1-field-price-und-0-amount
                    // alert(currentId);
                    $.ajax({
                        url: path + '/get_price_desc_bysku',
                        type: "POST",
                        data: "sku=" + skujq,
                        success: function (data) {
                            var bifurcate = data.split('|');
                            var price_get = bifurcate[0];
                            var title_get = bifurcate[1];
                            var desc_get = bifurcate[2];
                            var tit_desc = title_get + '\n\n' + desc_get;

                            //var price = jQuery.parseJSON( data );  

                            $('#edit-field-enter-products-info-und-' + curobject + '-field-price-und-0-amount').val(price_get);
                            $('#edit-field-enter-products-info-und-' + curobject + '-field-description-und-0-value').val(tit_desc);
                            $('#edit-field-enter-products-info-und-' + curobject + '-field-price-und-0-amount').attr("readonly", true);
                            $('#edit-field-enter-products-info-und-' + curobject + '-field-description-und-0-value').attr("readonly", true);

                        }
                    });



                });

                //$('input#address').click(function() {
                //    var value = $(this).val();
                //    alert(value);
                //    $('input[name=hidden_address]').val(value);
                // });
                $('#edit-get-mob-data').click(function () {
                    var cust_id = $('#cust_id').val();
                    $('input[name=customer_id]').val(cust_id);
                });

                //$('#order-punch-entityform-edit-form #field-add-more-submit').click(function() {

                //});
            });
        }
    };
})(jQuery);
 