jQuery(document).ready(function($) {
    $('#error_coupon').hide();
});
jQuery(window).load(function() {
    jQuery('#error_coupon').appendTo('.scCoupon-Phone .form-item-coupon');
    jQuery('#error_coupon').show();
});
(function($) {
    $(document).on("click", '.coupon_verify_cart', function(e) {
        if ($(window).width() < 736) {
            $('#error_coupon').appendTo('.scCoupon-Phone .form-item-coupon');
            $('#error_coupon').show();
        }
        $('#error_coupon').html("");
        var code = $('.coupon_code').val();
        var mpbile_no = $('.coupon_code_phone').val();
        if (code == "") {
            $('#error_coupon').html("<p>Please Enter Coupon Code");
        }
        else {
            e.preventDefault();
            var document_width = $(document).width() + "px";
            var document_height = $(document).height() + "px";
            $("body").append("<div class='ajax_overlay' style='top:0px;display:block;opacity:0.5;position:absolute;width:" + document_width + ";z-index:50000;background-color:black;height:" + document_height + "'><img class='ajax_overlay_loader' src='/sites/all/themes/bbd/images/ajax_loader.gif' style='position:fixed;'/></div>");
            $(".variant_overlay").hide();
            $(".ajax_overlay_loader").center();
            var url = 'add/coupon';
            $.ajax({
                type: "POST",
                cache: false, //for Chrome and IE8
                url: url,
                data: {mcoupon: code, mobile: mpbile_no},
                success: function (responce) {
                    //console.log(url);
                },
            });
            $(this).ajaxStop(function () {
                location.reload();
            });
        }
        return false;
    });

    $(document).on("click", '#remove-coupon', function (e) {
        e.preventDefault();
        //if (confirm("Are you sure want to delete this item - " + $(this).attr('title') + "?")) {
        // your deletion code
        var document_width = $(document).width() + "px";
        var document_height = $(document).height() + "px";
        $("body").append("<div class='ajax_overlay' style='top:0px;display:block;opacity:0.5;position:absolute;width:" + document_width + ";z-index:50000;background-color:black;height:" + document_height + "'><img class='ajax_overlay_loader' src='/sites/all/themes/bbd/images/ajax_loader.gif' style='position:fixed;'/></div>");
        $(".variant_overlay").hide();
        $(".ajax_overlay_loader").center();
        var url = 'remove/coupon';
        $.ajax({
            type: "GET",
            cache: false, //for Chrome and IE8
            url: url,
            success: function (responce) {
                // console.log(url);
            },
        });
        $(this).ajaxStop(function () {
            location.reload();
        });
        //}
        return false;
    });
})(jQuery);
