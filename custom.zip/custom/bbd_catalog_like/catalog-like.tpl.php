<div class="product-detail"> <span class="back-link"><?php // print($back_link); ?></span>
    <div class="prod-img-l">
        <div class="pmain-img"> <?php print_r(render($node['product:field_product_images'])); ?> </div>
        <div class="pd-r">
            <h1 id="page-title"><?php print($prod_title); ?></h1>
             <div class="sku-id-div"><span class="sku-id-lable">SKU ID:</span><?php print_r($sku) ?></div>
     
            <div class="pd-left">
              <div class="p-data1-kf">                  
                    <h4 class="keyf">Key Features</h4>
                    <?php print_r($top_features) ?> 
              </div>
                <div class="l-lnks">
                </div>
                <div class="p-buy-btn">
                    <div class="p-data4">
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td class="p-mrp"> <?php print_r(render($mrp_display)); ?> 
                                        <?php print_r(render($mrp_pack)); ?> 
                                        <?php print_r(render($bachat_res)); ?>                   
                                    </td>
                                    <td class="p-qty"></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                
                <div class="pdp-like"></div>
                <div class="pdp-like-button"> 
                    <?php print_r(render($like_button)); ?>
                </div>
            </div>
            <div>
                <div></div>
                <div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="prod-detail-r">
    <div class="pd-btm-l">
        <div class="offer-buy-outer">
            <div class="buy-p-at"></div>
        </div>
        <div class="pd-about-desc">
            <h2 class="pdesc-title">Product Description</h2>
            <?php
            print_r(render($node['product:field_product_short_description']));
            print $test;
            ?> </div>
        <div class="pd-about-features">
            
            <?php print($product_spec); ?>
        </div>        
    </div>
</div>

