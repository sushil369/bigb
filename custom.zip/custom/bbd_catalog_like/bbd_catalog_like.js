(function ($) {
    $(document).ready(function () {
        //$("div.logo").replaceWith('<div class ="logo"><img src="http://middleware-staging.bigbazaardirect.com/sites/default/files/BBDirect-logo.png" alt="Home"></div>');
		
		var $as = $('.pd-about-desc .pdesc-title').click(function() {
			$(this).parent().toggleClass('expandFD').children('.commerce-product-field').slideToggle();
		});		

		var $ds = $('.pd-about-features .pdesc-title').click(function() {
			$(this).parents('.pd-about-features').toggleClass('expandFD');
			$(this).siblings('.commerce-product-field, .sticky-enabled').slideToggle();
		});		
		
		/*PDP if features and description div is empty*/
		if ($.trim($('.pd-about-features').text()).length == 0 ) {
			$('.pd-about-features').hide();
		} else {
			$('.pd-about-features').show();
		}	
		if ($.trim($('.pd-about-desc').text()).length == 0 ) {
			$('.pd-about-desc').hide();
		} else {
			$('.pd-about-desc').show();
		}		
    });
})(jQuery);