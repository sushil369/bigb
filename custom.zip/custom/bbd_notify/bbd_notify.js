Drupal.behaviors.notifyMe = {
    attach: function (context, settings) {
        jQuery(document).ready(function ($) {
                    $(document).ajaxComplete(function () {
                    attach_notify_events();
            });
            attach_notify_events();
        });
        function attach_notify_events() {
                var node_id  = Drupal.settings.variant.node;
//                  console.log(node_id);
//                  console.log('"#notify-32317"');
            //jQuery(".bbd-prod-notify a").colorbox({inline: true, width: "50%", href: "\"#notify-" + node_id +"\"", className: "order-notify-popup",
            jQuery(".bbd-prod-notify a").colorbox({inline: true, width: "50%", href: "#notify-"+node_id, className: "order-notify-popup",
                onClosed: function () {

                }
            });
        }
    }
}




/*(function($) {
 $(document).ready(function() {
 Drupal.behaviors.notifyTpl = {
 attach: function(context, settings) {
 jQuery(document).ready(function() {
 jQuery(document).ajaxComplete(function() {
 attach_notify_events_to_element()
 });
 attach_notify_events_to_element()
 });
 function attach_notify_events_to_element() {
 // $(".bbd-prod-notify").click(function() {
 //var myString = 'notify-5200';
 
 // var myInteger = parseInt(myString);
 
 //console.log('hi');
 jQuery.colorbox({inline: true, width: "50%", href: "#notify-' . $nid . '", className: "order-notify-popup",
 onClosed: function() {
 // open the other colorBox
 jQuery("#colorbox").removeClass("kiran-le-notify");
 }
 });
 //});
 }
 }
 };
 });
 })(jQuery);
 */