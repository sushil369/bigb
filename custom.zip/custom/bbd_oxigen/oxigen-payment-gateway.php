<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);

$path = $_SERVER['DOCUMENT_ROOT'];
chdir($path);
define('DRUPAL_ROOT', rtrim(getcwd(), 'bbd_oxigen')); //the most important line
require_once DRUPAL_ROOT . '/includes/bootstrap.inc';
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);

$Mtrxid = $_GET['Mtrxid'];
$Amount = $_GET['Amount'];
$Mid = $_GET['Mid'];
$Mitem = $_GET['Mitem'];
$OtherVals = $_GET['OtherVals'];

$OrderId = $_GET['OrderId'];
$return_res_url = "http://" . $_SERVER['SERVER_NAME'] . '/oxigen-pg-return-url/' . $OrderId;

$oxigen_pg_url = variable_get('oxi_pg_url');
?>
<script language='javascript' type='text/javascript'>
      function go() { document.oxipgform.submit();}
</script>
<body onload='go()'>
    <form action='<?php echo $oxigen_pg_url; ?>' style='display:none;' name='oxipgform' method='POST'>
        <input type='Hidden' name='Mtrxid' value='<?php echo $Mtrxid; ?>' />
        <input type='Hidden' name='Amount' value='<?php echo $Amount; ?>' />
        <input type='Hidden' name='Mid' value='<?php echo $Mid; ?>' />
        <input type='Hidden' name='Mitem' value='<?php echo $Mitem; ?>' />
        <input type='Hidden' name='OtherVals' value='<?php echo $OtherVals; ?>' />
        <input type='Hidden' name='redirecturl' value='<?php echo $return_res_url; ?>' />
<!--        <input type='SUBMIT' name="GO" value="Go1" />-->
    </form>
</body>
