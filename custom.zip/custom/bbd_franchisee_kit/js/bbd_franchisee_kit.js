(function ($) {
    Drupal.behaviors.bbd_franchisee_kit = {
        attach: function (context) {
            jQuery(".kquantityPlus").once().click(function () {
                var current_qty = parseInt(jQuery(this).siblings('.form-type-textfield').find('input').val());
                var allowed_qty = parseInt(jQuery(this).siblings('.form-type-textfield').find('input').attr('data'));
                if (allowed_qty != current_qty) {
                    jQuery(this).siblings('.form-type-textfield').find('input').val(current_qty + 1);
                }
            });

            jQuery(".kquantityMinus").once().click(function () {
                var check = jQuery(this).siblings('.form-type-textfield').find('input').val();
                if (parseInt(check) > 0) {
                    jQuery(this).siblings('.form-type-textfield').find('input').val(parseInt(check) - 1);
                }
            });

            $('.radio-check').click(function (e) {
                var id = $(this).attr('data');
                $(this).parents('tr').siblings('tr').find('.radio-check').each(function () {
                    var curr_id = $(this).attr('data');
                    if (id == curr_id) {
                        $(this).prop('checked', false);
                        $(this).parents('tr');
                    }
                });
            });
        }
    };

})(jQuery);