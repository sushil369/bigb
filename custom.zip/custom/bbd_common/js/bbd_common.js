(function($) {
    $(document).ready(function() {
        $('.text-count').text('2000 characters left');
        $('.text-jq').keyup(function() {
            var max = 2000;
            var len = $(this).val().length;
            if (len >= max) {
                $('.text-count').text(' you have reached the limit');
                var str = $(this).val();
                var res = str.substring(0, 2000);
                $(this).val(res);

            } else {
                var ch = max - len;
                $('.text-count').text(ch + ' characters left');
            }
        });
        $('#link-rev').click(function(e) {
            e.preventDefault();
            $('.form-text').focus();
        });


        $(".ajax-processed").click(function() {
            var str = window.location.href;
            if (str.indexOf('custom/myaccount') > -1 && str.indexOf('edit') === 0) {
                //alert('Address has been set as default');
                setTimeout("Refresh()", 1000);
                window.location.reload();
            }
        });
        if ($('.cloud-thumbwrapper').lenght > 0) {
            $('.cloud-thumbwrapper').cycle({
                fx: 'fade', // here change effect to blindX, blindY, blindZ etc
                speed: 'slow',
                timeout: 0,
                next: '#next',
                prev: '#prev'
            });
        }
        $(".not-serviceable .sku_qty").after('<span class="pincode-error error not-serviceable-error">This Product is not serviceable kindly remove from shopping cart to proceed</span>');
        $(".out-of-stock .sku_qty").after('<span class="pincode-error error out-of-stock-error">Out of stock</span>');

        $.fn.center = function() {
            this.css("top", Math.max(0, (($(window).height() - $(this).outerHeight()) / 2) +
                    $(window).scrollTop()) + "px");
            this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) +
                    $(window).scrollLeft()) + "px");
            return this;
        };
        $("div.wrap:not(:first)").hide();
        $(document).on("hover", '.bbd-cnumber, .cart_hover_outer_main', function(event) {
            if ($(window).width() > 768) {
                $('.cart_hover_outer_main').toggle();
            }
        });
        $('.click-newsletter1').click(function(e) {
            e.preventDefault(e);
            $(".news-open").show("slow");
            $(".fixed-newsl").removeClass("isclose");
            $(".fixed-newsl").addClass("isopen");
        });
        $('.click-newsletter2').click(function(e) {
            e.preventDefault(e);
            $(".news-open").hide("slow");
            $(".fixed-newsl").removeClass("isopen");
            $(".fixed-newsl").addClass("isclose");
        });

        /*User pages wrap table in one div for scrollbar at bottom when columns are more*/
        $('.page-user .content-middle table').wrap('<div class="table_container">');

    });
    $(document).on("click", '.share-prod', function(event) {
        $("div.share-pop").show();
        event.preventDefault();
    });
    $(document).on("click", '.fb-close', function(event) {
        $("div.share-pop").hide();
        event.preventDefault();
    });
    Drupal.behaviors.amount_autofill = {
        attach: function(context) {
$('.form-item-franchisee-check input[id^=edit-franchisee-check]').attr('autocomplete', 'off');
            if ($(window).width() > 736) {
                $("#edit-franchisee-check").keydown(function(e) {
                    //$("#edit-delivery").keydown(function(e) {

                    if (!((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || (e.keyCode == 8) || (e.keyCode == 9) || (e.keyCode == 110) || (e.keyCode == 190))) {
                        e.preventDefault();
                        //}
                    }
                    //});
                });
            }
            /*popup Franchisee Details submit button inside form*/
            $('#checkout-add-cart-form, #modal-content .captcha, .fr-error-suffix').appendTo('#modal-content .form-item-franchisee-check.form-item');
            $('.add_to_cart_notification .error').insertBefore('#checkout-add-cart-form');
            $('input[name=captcha_response]').appendTo('.form-item.form-type-textfield.form-item-captcha-response');
            $('.reload-captcha-wrapper').appendTo('.captcha');
            $('#block-menu-menu-my-account').children('.content').children('ul.menu').children('li').addClass('leaf');

            /*PDP page view more offer click popup addClass*/
            $('.view-more-than-two a').on('click', function() {
                $('#modalContent').removeClass('add_to_cart_notification').addClass('offer-morethan-two-popup');
            });
            $('.close').on('click', function() {
                $('#modalContent').removeClass('add_to_cart_notification, offer-morethan-two-popup');
            });

            /*Hide popup when product is already added in wishlist*/
            jQuery('a.added-to-wishlist.add-wish-list').text('Added to Wishlist');
            jQuery('a.added-to-wishlist.add-wish-list').on('click', function(e) {
                jQuery('#colorbox, #cboxOverlay').hide();
                return false;
            });

            /*Payment option page oxigen*/
            if (jQuery('.oxigen-region-fieldset img').length > 1) {
                jQuery('.oxigen-region-fieldset img').parents('.oxigen-region-fieldset').addClass('Oxi-BBD-Wallet');
            }



            /*
             * For Franchisee code validation in sales report
             */
            jQuery("#edit-fr-code").keydown(function(e) {
                if (!((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || (e.keyCode == 8) || (e.keyCode == 9) || (e.keyCode == 110) || (e.keyCode == 190))) {
                    e.preventDefault();
                    //}
                }
            });


            $(document).on("click", '#add-to-wish-list', function(e) {
                e.preventDefault();
                var document_width = $(document).width() + "px";
                var document_height = $(document).height() + "px";
                $("body").append("<div class='ajax_overlay' style='top:0px;display:block;opacity:0.5;position:absolute;width:" + document_width + ";z-index:50000;background-color:black;height:" + document_height + "'><img class='ajax_overlay_loader' src='/sites/all/themes/bbd/images/ajax_loader.gif' style='position:fixed;'/></div>");
                $(".variant_overlay").hide();
                $(".ajax_overlay_loader").center();
                var uid = $(this).attr('uid');
                //alert(uid);
                if (uid) {
                    var product_id = $(this).attr('product_id');
                    var nid = $(this).attr('nid');
                    var token = $(this).attr('token');
                    var url = 'wishlist-actions/nojs/add/' + uid + '/' + product_id + '/' + nid + '?token=' + token;
                    $.ajax({
                        type: "GET",
                        cache: false, //for Chrome and IE8
                        url: url,
                        success: function(responce) {
                            //console.log('line item deleted');
                        },
                    });

                    $.ajax({
                        type: "GET",
                        cache: false, //for Chrome and IE8
                        url: "/customer-cart/remove_line_item?item=" + $(this).attr('sku_item') + "&sku=" + $(this).attr('sku'),
                        success: function(responce) {
                            //console.log('line item deleted');
                        },
                    });
                    $(this).ajaxStop(function() {
                        location.reload();
                    });
                }
                else {
                    window.location.href = "/user";
                }
                return false;
            });


            $(document).on("click", 'a.click-more-details', function(e) {
                $('html, body').animate({
                    scrollTop: $('.pd-about-features').offset().top
                }, 'slow');
            });




            $(document).on("click", '#remove-item, #remove-all-item', function(e) {
                e.preventDefault();
                //if (confirm("Are you sure want to delete this item - " + $(this).attr('title') + "?")) {
                // your deletion code
                var document_width = $(document).width() + "px";
                var document_height = $(document).height() + "px";
                $("body").append("<div class='ajax_overlay' style='top:0px;display:block;opacity:0.5;position:absolute;width:" + document_width + ";z-index:50000;background-color:black;height:" + document_height + "'><img class='ajax_overlay_loader' src='/sites/all/themes/bbd/images/ajax_loader.gif' style='position:fixed;'/></div>");
                $(".variant_overlay").hide();
                $(".ajax_overlay_loader").center();
                var url = "/customer-cart/remove_line_item?item=" + $(this).attr('sku_item') + "&sku=" + $(this).attr('sku');
                $.ajax({
                    type: "GET",
                    cache: false, //for Chrome and IE8
                    url: url,
                    success: function(responce) {
                        //console.log(url);
                    },
                });
                $(this).ajaxStop(function() {
                    location.reload();
                });
                //}
                return false;
            });

            /* $('#remove-all-item').on("click", function(e) {
             e.preventDefault();
             //if (confirm("Are you sure want to delete this item - " + $(this).attr('title') + "?")) {
             // your deletion code
             var document_width = $(document).width() + "px";
             var document_height = $(document).height() + "px";
             $("body").append("<div class='ajax_overlay' style='top:0px;display:block;opacity:0.5;position:absolute;width:" + document_width + ";z-index:50000;background-color:black;height:" + document_height + "'><img class='ajax_overlay_loader' src='/sites/all/themes/bbd/images/ajax_loader.gif' style='position:fixed;'/></div>");
             $(".variant_overlay").hide();
             $(".ajax_overlay_loader").center();
             var url = "/customer-cart/remove_line_item?item=" + $(this).attr('sku_item') + "&sku=all" + $(this).attr('sku');
             $.ajax({
             type: "GET",
             cache: false, //for Chrome and IE8
             url: url,
             success: function(responce) {
             //console.log(url);
             },
             });
             $(this).ajaxStop(function() {
             location.reload();
             });
             //}
             return false;
             });*/
            $('#edit-quantity').change(function(e) {
                $('.pincode-error-pdp').remove();
                var id = $(this).attr('id');
                var qty = $('#' + id).attr('value');
                //console.log(id);
                //console.log(qty);
                var bool = 1;
                if (Math.floor(qty) != qty || !$.isNumeric(qty)) {
                    $('[value="Add to cart"]').attr('disabled', 'disabled');
                    $('#edit-quantity').after('<span class="pincode-error-pdp error">Invalid Quntity Supplied</span>');
                    bool = 0;
                }
                if (qty > 999) {
                    $('[value="Add to cart"]').attr('disabled', 'disabled');
                    $('#edit-quantity').after('<span class="pincode-error-pdp error">Maximum Qunatity reached</span>');
                    bool = 0;
                }
                if (bool) {
                    $('[value="Add to cart"]').removeAttr('disabled');
                }
            });
            $('.qty_c input').change(function(e) {
                $('.pincode-error').remove();
                var id = $(this).attr('id');
                var qty = $('#' + id).attr('value');
                var SKU = $('#' + id).attr('sku');
                if (Math.floor(qty) != qty || !$.isNumeric(qty)) {
                    $('#' + SKU + ' .sku_qty').after('<span class="pincode-error error">Invalid Quntity Supplied</span>');
                }
                else {
                    if (qty > 999) {
                        $('#' + SKU + ' .sku_qty').after('<span class="pincode-error error">Maximum Qunatity reached</span>');
                    }
                    else {
                        e.preventDefault();
                        var document_width = $(document).width() + "px";
                        var document_height = $(document).height() + "px";
                        $("body").append("<div class='ajax_overlay' style='top:0px;display:block;opacity:0.5;position:absolute;width:" + document_width + ";z-index:50000;background-color:black;height:" + document_height + "'><img class='ajax_overlay_loader' src='/sites/all/themes/bbd/images/ajax_loader.gif' style='position:fixed;'/></div>");
                        $(".variant_overlay").hide();
                        $(".ajax_overlay_loader").center();
                        $.ajax({
                            type: "GET",
                            cache: false, //for Chrome and IE8
                            url: "/customer-cart/remove_line_item?item=" + $('#' + id).attr('sku_item') + "&sku=" + SKU + "&qty=" + qty,
                            success: function(responce) {
                                //console.log('line item deleted');
                            },
                        });
                        $(this).ajaxStop(function() {
                            location.reload();
                        });
                        return false;
                    }
                }
            });
            $(".field-name-commerce-product input.form-text").focusout(function() {
                var this_var = $(this);
                var sku = this_var.val();
                $.ajax({
                    type: "GET",
                    url: location.origin + "/bundle/product/" + sku + "/autofill",
                    success: function(responce) {
                        this_var.parents(".field-name-commerce-product").siblings(".field-name-commerce-unit-price").find(".form-text").val(responce.amount);
                        this_var.parents(".field-name-commerce-product").siblings(".form-item-field-bundle-products-und-form-quantity").find(".form-text").val(responce.stock);
                        this_var.parents(".field-name-commerce-product").siblings(".field-name-field-franchise-comission").find(".form-text").val(responce.comission);
                    },
                });
            });


            $(document).on("click", '.pincode_verify_cart', function(e) {


                $(".error-row").removeClass();
                e.preventDefault();
                $('.pincode-error').remove();
                var pin_code = $('#edit-pincode').val();
                $('#nearest-five-pincode').attr('pincode', pin_code);
                var bool = true;
                if (pin_code.length != 6) {
                    bool = false;
                    $('#edit-pincode-submit').after('<span class="pincode-error error">Please enter 6 digits</span>');
                }
                if (isNaN(pin_code)) {
                    bool = false;
                    $('#edit-pincode-submit').after('<span class="pincode-error error">Please enter valid Pincode</span>');
                }
                if (bool) {
                    $("tr .error-row").removeClass();
                    $.ajax({
                        type: "POST",
                        cache: false, //for Chrome and IE8
                        url: "/pincode/verify",
                        data: {pin_code: pin_code},
                        success: function(response) {
                            if (!response.status) {
                                $('.pincode-error').remove();
                                if (!$.isEmptyObject(response['non_serviceable'])) {
                                    $.colorbox({href: ' #not-serviceable-inner', className: 'pincode_verify'});
                                    $.each(response.non_serviceable, function(key, value) {
                                        $('#' + value.SKU + ' .sku_qty').after('<span class="pincode-error error">This Product is not serviceable kindly remove from shopping cart to proceed</span>');
                                        $('#' + value.SKU).addClass('error-row');
                                    });
                                }
                                else if (!$.isEmptyObject(response['out_of_stock'])) {
                                    $.colorbox({href: ' #out-of-stock-inner', className: 'pincode_verify'});
                                    $.each(response.out_of_stock, function(key, value) {
                                        $('#' + value.SKU + ' .sku_qty').after('<span class="pincode-error error">Out of stock</span>');
                                        $('#' + value.SKU).addClass('error-row');
                                    });
                                }
                                else {
                                    $.colorbox({href: ' #not-serviceable-inner', className: 'pincode_verify'});
                                }
                            }
                            else {
                                $.colorbox({href: ' #serviceable-inner', className: 'pincode_verify'});
                            }
                        },
                    });
                    return false;
                }
            });

            $('#edit-delivery-date-filter').change(function(e) {
                var filter = $(this).val();
                var rows = $('#cart_line_items').children('table.sticky-enabled').find('tbody tr');
                var document_width = $(document).width() + "px";
                var document_height = $(document).height() + "px";
                var loading_div = "<div id='ajax_loading_div' style='top:0px;display:block;opacity:0.5;position:absolute;width:" + document_width + ";z-index:50000;background-color:black;height:" + document_height + "'><img class='ajax_overlay_loader' src='/sites/all/themes/bbd/images/ajax_loader.gif' style='position:fixed; top:250px !important;'/></div>";

                if (filter == 0) {
                    $("body").append(loading_div);
                    $(".ajax_overlay_loader").center();

                    rows.show();

                    setTimeout(function() {
                        jQuery('#ajax_loading_div').remove();
                    }, 800);
                }
                else {
                    $("body").append(loading_div);
                    $(".ajax_overlay_loader").center();

                    rows.not('[timestamp=' + filter + ']').hide();
                    rows.filter('[timestamp=' + filter + ']').show();

                    setTimeout(function() {
                        jQuery('#ajax_loading_div').remove();
                    }, 800);

                }

            });
            jQuery('#nearest-five-pincode').on('click', function() {
                jQuery('#modalContent').addClass('nearest_pincode_popup');
            });
            jQuery('#modalContent .close').on('click', function() {
                jQuery('#modalContent').removeClass('nearest_pincode_popup');
            });
            jQuery('#fg_earn_wrapper .form-submit').appendTo('.form-item-fg-loyalty-card');

        }
    };

})(jQuery);

// ################# Vikee ##############
/**
 * js for Touch Event for Responsive website
 * @returns {window|String}
 * 
 */
Drupal.settings.isTouchDevice = function() {
    return "ontouchstart" in window;
}

if (Drupal.settings.isTouchDevice()) {
    Drupal.behaviors.jQueryMobileSlideShowTouchAdvance = {
        attach: function(context, settings) {
            self = Drupal.behaviors.jQueryMobileSlideShowTouchAdvance;
            jQuery.each(jQuery(".views_slideshow_cycle_main.viewsSlideshowCycle-processed"), function(idx, value) {
                value.addEventListener("touchstart", self.handleTouchStart);
                jQuery(value).addClass("views-slideshow-mobile-processed");
            })
            jQuery(self).bind("swipe", self.handleSwipe);
        },
        detach: function() {
        }, original: {x: 0, y: 0},
        changed: {x: 0, y: 0}, direction: {x: "", y: ""}, fired: false,
        handleTouchStart: function(evt) {
            self = Drupal.behaviors.jQueryMobileSlideShowTouchAdvance;
            if (evt.touches) {
                if (evt.targetTouches.length != 1) {
                    return false;
                } // don't respond to gestures
                if (evt.touches.length) {
                    //evt.preventDefault();
                    evt.stopPropagation()
                }
                self.original = {x: evt.touches[0].clientX, y: evt.touches[0].clientY}
                self.target = jQuery(this).attr("id").replace("views_slideshow_cycle_main_", "");
                Drupal.viewsSlideshow.action({"action": "pause", "slideshowID": self.target});
                evt.target.addEventListener("touchmove", self.handleTouchMove);
                evt.target.addEventListener("touchend", self.handleTouchEnd);
            }
        },
        handleTouchMove: function(evt) {
            self = Drupal.behaviors.jQueryMobileSlideShowTouchAdvance;
            self.changed = {
                x: (evt.touches.length) ? evt.touches[0].clientX : evt.changedTouches[0].clientX,
                y: (evt.touches.length) ? evt.touches[0].clientY : evt.changedTouches[0].clientY
            };
            h = parseInt(self.original.x - self.changed.x), v = parseInt(self.original.y - self.changed.y);
            if (h !== 0) {
                self.direction.x = (h < 0) ? "right" : "left";
            }
            if (v !== 0) {
                self.direction.y = (v < 0) ? "up" : "down";
            }
            if ((h + v) != 0) {
                jQuery(self).trigger("swipe");
            }
        },
        handleTouchEnd: function(evt) {
            self = Drupal.behaviors.jQueryMobileSlideShowTouchAdvance;
            evt.target.removeEventListener("touchmove", self.handleTouchMove);
            evt.target.removeEventListener("touchend", self.handleTouchEnd);
            self.fired = false;
        },
        handleSwipe: function(evt) {
            self = Drupal.behaviors.jQueryMobileSlideShowTouchAdvance;
            if (evt != undefined && self.fired == false) {
                Drupal.viewsSlideshow.action({"action": (self.direction.x == "left") ? "nextSlide" : "previousSlide", "slideshowID": self.target});
                self.fired = true; //only fire advance once per touch
            }
        }
    }
}
// END

jQuery(window).load(function() {
    jQuery('#search-box #block-search-form input.form-submit').prop('disabled', true);

    jQuery('#search-box .form-type-textfield input').keyup(function() {
        var searchValue = jQuery(this).val();

        if (searchValue == '') {
            jQuery('#search-box #block-search-form input.form-submit').prop('disabled', true);
            jQuery('#search-box .form-type-textfield input').focus();

        } else {
            jQuery('#search-box #block-search-form input.form-submit').prop('disabled', false);
        }
    });
});