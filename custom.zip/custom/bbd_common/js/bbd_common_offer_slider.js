(function($) {
    $(document).ready(function() {
//        var img_count = jQuery('.poffers');
            //jQuery('.poffers').bxSlider();
            jQuery('.poffersul').bxSlider({
                infiniteLoop: false,
                hideControlOnEnd: true
            });

    });

})(jQuery);


