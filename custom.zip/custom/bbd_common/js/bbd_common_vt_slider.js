(function ($) {

    $(document).ready(function () {
// start slide arrow on PDP page

        var img_count = jQuery('.cloud-thumbwrapper');

        img_count.length;

        if (img_count.length > 5) {
            jQuery('.prev_button, .next_button').show();
        }
        else {
            jQuery('.prev_button, .next_button').hide();
        }

        var i = 0;
        jQuery(".cloud-thumbwrapper").each(function () {
            if (i < 5) {
                jQuery(this).addClass('show-images');
            }
            else {
                jQuery(this).addClass('hide-images');
            }
            i++;
        });

        jQuery(".next_button").click(function () {
            jQuery(".cloud-thumbwrapper").each(function () {
                if (jQuery(this).hasClass("show-images")) {
                    jQuery(this).addClass("hide-images", 100).removeClass("show-images", 100);
                    jQuery('.next_button').attr('disabled', true);
                    jQuery('.prev_button').attr('disabled', null);
                }
                else {
                    jQuery(this).addClass("show-images", 100).removeClass("hide-images", 100);
                }
            });
        });

        jQuery(".prev_button").click(function () {
            jQuery(".cloud-thumbwrapper").each(function () {
                if (jQuery(this).hasClass("show-images")) {
                    jQuery(this).addClass("hide-images", 100).removeClass("show-images", 100);
                    jQuery('.prev_button').attr('disabled', true);
                    jQuery('.next_button').attr('disabled', null);
                }
                else {
                    jQuery(this).addClass("show-images", 100).removeClass("hide-images", 100);
                }
            });
        });

    });
//END of arrow 
})(jQuery);