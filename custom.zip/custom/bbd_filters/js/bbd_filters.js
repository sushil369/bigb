/**
 * @file
 * jQuery for Filter module.
 */
jQuery(document).ready(function($) {

    // submit desktop form 
    jQuery('.desktopForm .form-checkbox, .desktopForm .form-type-radio input').click(function() {
        jQuery('#bbd-filters-content-form').submit();
    });

    // submit mobile form 

    jQuery('#applyMobileFilters, #price_submit, .mobileForm .full-expand .form-type-radio input').click(function() {
        jQuery('#bbd-filters-content-responsive-form').submit();
    });
	
        /*Sticky filter*/
		var filterEl = $('#block-bbd-common-sort-filter-responsive');
        var filterPosition = filterEl.offset().top;
        $(window).scroll(function() {
            var scrollPosition = $(window).scrollTop();
            if (scrollPosition >= filterPosition) {
                $('#block-bbd-common-sort-filter-responsive').addClass('fixedFilter');
            } else {
                $('#block-bbd-common-sort-filter-responsive').removeClass('fixedFilter');
            }
        });	
    
});

jQuery(window).load(function() {
    var getWidth = jQuery(window).width();

    if (getWidth < 768) {
        jQuery('.desktopForm').remove();
    }

    if (getWidth < 768 && jQuery('#slider-range').hasClass('desktopSlider')) {
        jQuery('.desktopSlider').remove();
    }

    jQuery('.full-expand .options').hide();
    jQuery('.defaultshow').show();

    jQuery('.h6').click(function() {
        jQuery('.full-expand .options').hide();
        jQuery(this).siblings('.options').show();

    });

    jQuery('#filter-container .full-expand').first().addClass('active');
    jQuery('#filter-container .full-expand').click(function() {
        jQuery(this).addClass('active');
        jQuery(this).siblings('li').removeClass('active');

        if (jQuery(this).hasClass('filter-by-category')) {
            jQuery('#applyMobileFilters').prop('disabled', true);
            jQuery('#applyMobileFilters').css('background-color', '#7f94a4');
        } else {
            jQuery('#applyMobileFilters').prop('disabled', false);
            jQuery('#applyMobileFilters').css('background-color', '#002949');
        }
    });

    jQuery('.filterBy').click(function() {

		jQuery('body').addClass('filterO');
        jQuery('#sidebar-left').show();
        jQuery('#block-bbd-filters-specs-filter').show();
        jQuery('.filter-container li').first().addClass('show-options');
        jQuery('.show-options .options').show();

        if (jQuery('#filter-container .full-expand').hasClass('filter-by-category')) {
            jQuery('#applyMobileFilters').prop('disabled', true);
            jQuery('#applyMobileFilters').css('background-color', '#7f94a4');
        }
		
		var filterHeaderHeight = jQuery('.filterPopup').height();
		var windowH = jQuery(window).height();
		var FilterHeight = parseInt(windowH - filterHeaderHeight);
		jQuery('.filter-container, .filter-container > li .options').css({
			'height': FilterHeight
		});		

    });

    jQuery('.filterHeader .back-btn').click(function() {
		jQuery('body').removeClass('filterO');
        jQuery('#sidebar-left').hide();
        jQuery('#block-bbd-filters-specs-filter').hide();
    });
});