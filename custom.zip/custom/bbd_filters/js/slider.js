/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


(function($) {

    Drupal.behaviors.MODULENAME = {
        attach: function(context, settings) {

            var getWidth = jQuery(window).width();

            if (getWidth < 736) {
                jQuery('.desktopForm, #price_submit').remove();
            }

            if (getWidth < 736 && jQuery('#slider-range').hasClass('desktopSlider')) {
                jQuery('.desktopSlider').remove();
            }

            $("#slider-range").slider({
                range: true,
                min: settings.slider.min - 0,
                max: settings.slider.max - 0,
                values: [settings.slider.filtered_min, settings.slider.filtered_max],
                step: 1,
                slide: function(event, ui) {
                    $("#slider-amount-min").html('Rs ' + ui.values[0]);
                    $("#amount-min").val(ui.values[0]);
                    $("#slider-amount-max").html('Rs ' + ui.values[1]);
                    $("#amount-max").val(ui.values[1]);
                }
            });


            // jQuery('.form-item-min, #slider-range, .form-item-max').wrapAll('<div class="price_range">');

            $("#amount-min").val($("#slider-range").slider("values", 0));
            $("#amount-max").val($("#slider-range").slider("values", 1));



            $("#slider-amount-min").html('Rs ' + $("#slider-range").slider("values", 0));
            $("#slider-amount-max").html('Rs ' + $("#slider-range").slider("values", 1));

            var mini = parseInt($("#amount-min").val());
            var maxi = parseInt($("#amount-max").val());

            if (maxi == mini) {
                $('#slider-range').slider({disabled: "true"});
            }
            else if (maxi != mini) {
                $('#slider-range').slider('enable');
            }


            //Allow only numbers, dot, Tab and Backspace in 'Amount' textbox
            $("#amount-min, #amount-max").keydown(function(e) {
                if (!((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || (e.keyCode == 8) || (e.keyCode == 9) || (e.keyCode == 110) || (e.keyCode == 190))) {
                    e.preventDefault();
                }

            });

            $("#amount-min").blur(function() {

                var min = parseInt($("#amount-min").val());
                var max = parseInt($("#amount-max").val());
                if ((min) < (settings.slider.min))
                {
                    min = settings.slider.min;
                    $("#amount-min").val(min);
                }

                if ((min) > (max))
                {
                    min = max;
                    $("#amount-min").val(min);
                }
                $("#slider-range").slider('values', 0, min);
                $("#slider-amount-min").html('Rs ' + min);
                jQuery('.price_lower_limit').val(min);

            });

            $("#amount-max").blur(function() {

                var max = parseInt($("#amount-max").val());
                var min = parseInt($("#amount-min").val());

                if ((max) > (settings.slider.max))
                {
                    max = settings.slider.max;
                    $("#amount-max").val(max);
                }

                if ((max) < (min))
                {
                    max = min;
                    $("#amount-max").val(max);
                }
                $("#slider-range").slider('values', 1, max);
                $("#slider-amount-max").html('Rs ' + max);
                jQuery('.price_upper_limit').val(max);

            });

            //check enter button clicked in From textbox.
            $('#amount-min').keydown(function(e) {
                if (e.keyCode == 13) {
                    var min = parseInt($("#amount-min").val());
                    var max = parseInt($("#amount-max").val());
                    if (getWidth > 736)
                        slider_submit_func(min, max);
                    if (getWidth <= 736) {
                        jQuery('.price_lower_limit').val(min);
                        jQuery('.price_upper_limit').val(max);
                    }
                }
            })


            //check enter button clicked in To textbox.
            $('#amount-max').keydown(function(e) {
                if (e.keyCode == 13) {
                    var min = parseInt($("#amount-min").val());
                    var max = parseInt($("#amount-max").val());
                    if (getWidth > 736)
                        slider_submit_func(min, max);
                    if (getWidth <= 736) {
                        jQuery('.price_lower_limit').val(min);
                        jQuery('.price_upper_limit').val(max);
                    }
                }
            })



            //Go button is clicked
            $("#price_submit").click(function(e) {
                var min = parseInt($("#amount-min").val());
                var max = parseInt($("#amount-max").val());
                if (getWidth > 736)
                    slider_submit_func(min, max);
                if (getWidth <= 736) {
                    jQuery('.price_lower_limit').val(min);
                    jQuery('.price_upper_limit').val(max);
                }
            });

            //on slide stop submit FROM and TO value
            $("#slider-range").on("slidestop", function(event, ui) {
                var min = ui.values[0];
                var max = ui.values[1];
                if (getWidth > 736)
                    slider_submit_func(min, max);
                if (getWidth <= 736) {
                    jQuery('.price_lower_limit').val(min);
                    jQuery('.price_upper_limit').val(max);
                }
            });

            // submit search value from (From and To) 
            function slider_submit_func(minimum, maximum) {

                if ((maximum) > (settings.slider.max))
                {
                    maximum = settings.slider.max;
                }
                if ((minimum) < (settings.slider.min))
                {
                    minimum = settings.slider.min;
                }

                var price = minimum + '-' + maximum;

                var url = window.location.href;

                if (url.indexOf('?') > -1) {
                    if (url.indexOf('price=') > -1) {
                        var regEx = /([?&]price)=([^#&]*)/g;
                        url = url.replace(regEx, '$1=' + price);
                    } else {
                        url += '&price=' + price;
                    }

                } else {
                    url += '?price=' + price;
                }
                window.location.href = url;
            }


        }
    };

})(jQuery);
