(function ($) {
    Drupal.behaviors.serviceabilityt_check = {
        attach: function (context) {
            //var a = window.location.origin;
            if (!window.location.origin) {
                var base_url_all = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');  //this code is for IE where window.location.origin is not work
            } else {
                var base_url_all = window.location.origin;
            }
            var a = base_url_all;
            jQuery(document).on('click', '#pin_ser, #serve-change', function (event) {
                //console.log('test');  
                var serve_id = this.id;
                if (serve_id != 'serve-change') {
                    $('.pincode-error').remove();
                    var pin_code = $('#node_pincode').val();
                    var bool = true;
                    if (pin_code.length != 6) {
                        bool = false;
                        $('#pin_ser').after('<span class="pincode-error error">Please enter 6 digits</span>');
                    }
                    if (isNaN(pin_code)) {
                        bool = false;
                        $('#pin_ser').after('<span class="pincode-error error">Please enter valid Pincode</span>');
                    }
                }
                else {
                    bool = true;
                    pin_code = 'change';
                }
                var nid = $('#pincode_serviceability').attr('nid');

                if (bool) {
                    $.ajax({
                        type: "POST",
                        //contentType: 'application/json; charset=utf-8',
                        dataType: 'html',
                        cache: false, //for Chrome and IE8
                        url: a + "/verify-serviceability",
                        data: {pin_code: pin_code, nid: nid},
                        success: function (response) {
                            $('#serve_pincode').replaceWith(response);
                            Drupal.attachBehaviors(context);
                        }
                    });
                }
                ;
                event.preventDefault();
            });
            // jQuery(document).on('click','#nearest-five-pincode', function(event) {
            //          Drupal.attachBehaviors(context);
//        $("#colorbox").removeClass();
//        $("#colorbox").addClass("nearest-five-pincode");
//        var pin_code = $(this).attr('pincode');
//        var product_id = $('input[name=product_id]').val();
//        $.ajax({
//          type: "POST",
//          //contentType: 'application/json; charset=utf-8',
//            dataType: 'html',
//           cache: false, //for Chrome and IE8
//           url: a + "/nearest-pincode",
//            data: {pin_code: pin_code, product_id : product_id},
//            success: function(response) {
//              $.colorbox({html:response, className: 'nearest-five-pincode'});
//          },
//			complete : function(){
//               $("body #colorbox").addClass("nearest-five-pincode");
//            }
//      });
//       event.preventDefault();
            //   });
        }
    };
})(jQuery);