(function($) {
    $(document).ready(function() {

  // start slide arrow on PDP page 
        var img_qc_image = jQuery('.cloud-thumbwrapper');
        img_qc_image.length;
        console.log(img_qc_image.length);
        if (img_qc_image.length > 5) {
            console.log(img_qc_image.length);
            jQuery('.prev_button, .next_button').show();
        }
        else {
            jQuery('.prev_button, .next_button').hide();
        }

        var i = 0;
        jQuery(".cloud-thumbwrapper").each(function() {
            if (i < 5) {
                jQuery(this).addClass('show-images');
            }
            else {
                jQuery(this).addClass('hide-images');
            }
            i++;
        });

        jQuery(".next_button").click(function() {
            jQuery(".cloud-thumbwrapper").each(function() {
                if (jQuery(this).hasClass("show-images")) {
                    jQuery(".show-images").switchClass("show-images", "hide-images", 100);
                    jQuery('.next_button').attr('disabled', true);
                    jQuery('.prev_button').attr('disabled', null);
                }
                else {
                    jQuery(".hide-images").switchClass("hide-images", "show-images", 100);
                }
            });
        });

        jQuery(".prev_button").click(function() {
            jQuery(".cloud-thumbwrapper").each(function() {
                if (jQuery(this).hasClass("show-images")) {
                    jQuery(".show-images").switchClass("show-images", "hide-images", 100);
                    jQuery('.prev_button').attr('disabled', true);
                    jQuery('.next_button').attr('disabled', null);
                }
                else {
                    jQuery(".hide-images").switchClass("hide-images", "show-images", 100);
                }
            });
        });
//END of arrow 

    });
})(jQuery);


