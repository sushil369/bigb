
<div class="qc-product-detail"><button class="prev_button" disabled="disabled">Prev</button>
      <button class="next_button">Next</button>
    <div class="pd-about-img">
        <?php print_r(render($product_image)); ?> 
    </div>
    <div class="pd-data">
        <div class="pd-about-title">
            <h2 class="pd-title">Title: <?php print_r(render($prod_title)); ?></h2>
        </div>
        <div class="pd-about-sku">
            <h2 class="pd-sku">SKU: <?php print_r(render($sku)); ?></h2>
        </div>
        <div class="pd-about-feature">
            <h2 class="pd-feature">Key Features:</h2>
            <?php print_r(render($top_features_display)); ?>
        </div>   
        <div class="pd-about-spec">
            <h2 class="pd-feature">Product Description:</h2>
            <?php print_r(render($field_product_short_description)); ?>
        </div>
    </div>
</div>