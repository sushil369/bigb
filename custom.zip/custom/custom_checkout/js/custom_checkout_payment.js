(function ($) {
    $(document).ready(function () {
        $('form').bind("keypress", function (e) {
            if (e.keyCode == 13)
                return false;
        });
        jQuery(document).on('click', '.form-type-radio', function () {
            jQuery('.first, .last').removeClass('selected');
            jQuery(this).children().addClass('selected');

            jQuery('.option.selected').click(function () {



            });


        });
        // this code to set frenchisee id
        //jQuery('.pay-at-franchisee').attr("disabled", disable);
        jQuery(document).on("click", 'input[name=shipping_address]:radio', function () {
            jQuery('.first, .last').removeClass('selected');
            jQuery(this).next().children().addClass('selected');
            jQuery('#frenchisee').val(jQuery(this).val());
            jQuery('.pay-at-franchisee').prop("disabled", false);
            //console.log('hi2');
        });
        // This code for custom payment
        jQuery('#edit-pp-0').parent().addClass('selected');
        jQuery('#edit-submit').addClass('payment');
        jQuery(document).on('click', '#edit-pp-0, #edit-pp-1, #edit-pp-2, .option, ', function () {
            jQuery('.form-item-pp').removeClass('selected');
            jQuery(this).parent().addClass('selected');
            jQuery('#edit-payback-card1').focus();
        });




    });
    Drupal.behaviors.bbd_payback_error = {
        attach: function (context) {
            if ($('#edit-payback-card4').length > 0) {
                $('.apply_b_pay').mouseenter(function () {
                    var len = $('#edit-payback-card4').val().length;
                    if (len == 4) {
//                        if (!$('#edit-payback-card4').hasClass('processed')) {
//                            $('#edit-payback-card4').focus().addClass('processed');
//                        }
                        $('#edit-payback-card4').focus();
                    }
                });
            }
        }

    };
})(jQuery);
 