(function ($) {
    $(document).ready(function () {
        jQuery('.shipping-address-checkbox').click(function () {
            if ($('.shipping-address-checkbox').is(':checked')) {
                $("#build-address-form").hide();
                $('#page-title').hide();
            }
            else {
                $("#build-address-form").show();
                $('#page-title').show();
            }
        });
        jQuery('.billing-address-checkbox').click(function () {
            if (this.checked) {
                $("#new-billing-fileds-wrapper").hide();
            }
            else {
                $("#new-billing-fileds-wrapper").show();
            }
        });

//        $("#edit-shipping-postal-code").blur(function (e) {
//            e.preventDefault();
//            var pincode = $(this).attr('value');
//            $.ajax({
//                type: "POST",
//                url: "/get/city/state",
//                data: "pincode=" + pincode,
//                success: function (response) {
//
//                    if (!response['state'] || !response['city']) {
//                        $("input[name='shipping_administrative_area']").val('');
//                        $("input[name='shipping_locality']").val('');
//                        $("input[name='shipping_administrative_area']").removeAttr('readonly');
//                        $("input[name='shipping_locality']").removeAttr('readonly');
//                    }
//                    else {
//                        $("input[name='shipping_administrative_area']").val(response['state']);
//                        $("input[name='shipping_locality']").val(response['city']);
//                        $("input[name='shipping_administrative_area']").attr('readonly', 'readonly');
//                        $("input[name='shipping_locality']").attr('readonly', 'readonly');
//                    }
//                }
//            });
//        });
//        $("#edit-billing-postal-code").blur(function (e) {
//            e.preventDefault();
//            var pincode = $(this).attr('value');
//            $.ajax({
//                type: "POST",
//                url: "/get/city/state",
//                data: "pincode=" + pincode,
//                success: function (response) {
//                    $("#edit-billing-administrative-area").val(response['state']);
//                    $("#edit-billing-locality").val(response['city']);
//                }
//            });
//        });
        //$('#edit-commerce-customer-address-und-0-locality').attr('readonly', true);
        //$('#edit-commerce-customer-address-und-0-administrative-area').attr('readonly', true);
        $("#edit-commerce-customer-address-und-0-postal-code").keyup("change", function (e) {
            e.preventDefault();
            var pincode = $(this).attr('value');
            $.ajax({
                type: "POST",
                url: "/get/city/state",
                data: "pincode=" + pincode,
                success: function (response) {
                    $("#edit-commerce-customer-address-und-0-locality").val(response['city']);
                    $("#edit-commerce-customer-address-und-0-administrative-area").val(response['state']);
                }
            });
        });

        $('.saved-shipping-address').click(function () {
            $(this).find('.form-radio').prop('checked', true);
            $('.saved-shipping-address').removeClass('sel-add');
            $(this).addClass('sel-add');
        });


        $('.editaction').click(function () {

            $("#editp").show();
            $("#viewpart").hide();

        });


        // slider for shipping address
        if ($('.bxslider').length > 0) {
            $('.bxslider').bxSlider({
                minSlides: 1,
                maxSlides: 2,
                slideWidth: 360,
                slideMargin: 10,
                infiniteLoop: false
            });
        }

        var str = window.location.href;
        if (str.indexOf('custom/myaccount') > -1 && str.indexOf('edit') === 0) {

            var count_checked = jQuery("input[id*='edit-myselector']:checked").length;
            if (count_checked > 0) {
                jQuery(".hide_confirm").show();
            } else {
                jQuery(".hide_confirm").hide();
            }
        }
    });


    Drupal.behaviors.confirm_pending = {
        attach: function (context) {
            $('#edit-search').focus(function () {
                $(this).val('');
            });
            $('.view-item-order').click(function (e) {
                e.preventDefault();
                var order_id = $(this).attr('id');
                $("#linedetail" + order_id).slideToggle();
            });


        }
    };
//  Drupal.behaviors.hide_confirm_myaccount = {
//    attach: function(context) {
//      // jQuery("input[id*='edit-myselector']").on("click", function(e)  {
//      // jQuery(".hide_confirm").show();
//      //});
//      jQuery(".form-checkbox").change(function() {
//
//        var count_checked = jQuery("input[id*='edit-myselector']:checked").length;
//        if (count_checked > 0) {
//          jQuery(".hide_confirm").show();
//          
//          jQuery("#selected_orders").html(count_checked + ' Orders selected');
//        } else {
//          jQuery(".hide_confirm").hide();
//        }
//
//      });
//
//      jQuery(".select-all").change(function() {
//        setTimeout(function() {
//          var count_checked = jQuery("input[id*='edit-myselector']:checked").length;
//          if (count_checked > 0) {
//            jQuery(".hide_confirm").show();
//            
//            jQuery("#selected_orders").html(count_checked + ' Orders selected');
//          } else {
//            jQuery(".hide_confirm").hide();
//          }
//        }, 1000);
//      });
//
//
//
//
//    }
//
//  };

    $(document).on("click", '#pane_area #submit', function () {
        $.ajax({
            type: "POST",
            url: "custom_checkout_pane",
            //data: "template_name="+template_name+"&email="+email+"&frequency="+frequency+"&isbn13="+isbn13+"&qty="+qty+"&price="+price+"&currency="+currency+"&disc="+disc+"&phone_no="+phone_no+"&address="+address,
            success: function (msg) {

                $(myForm).prop('disabled', true);
                $('#edit-name').attr("readonly", true);

            }
        });


    });

    $(document).on("click", ".search-picode", function () {
        var p_code = $('#edit-franchisee-postal-code').attr('value');
        if (!p_code) {
            return false;
        }
        $.ajax({
            type: "POST",
            url: "/franchisee/address",
            data: "p_code=" + p_code,
            success: function (response) {
                var main_div = $(".main-div", response);
                $(".main-div").replaceWith(main_div);
            }
        });
    });


    $(document).on("click", ".search-cities", function () {
        var city = $(this).attr('item');
        $.ajax({
            type: "POST",
            url: "/franchisee/address",
            data: "city=" + city,
            success: function (response) {
                var main_div = $(".main-div", response);
                $(".main-div").replaceWith(main_div);
            }
        });
    });
    $('.edit-profile-my-personal-information-field-test-und-0-value-datepicker-popup-0').html('DOB');

})(jQuery);

(function ($) {
    $(document).ready(function () {
        $('.click-newsletter1').click(function (e) {
            e.preventDefault();
            $(".news-open").slideToggle();
            $(".fixed-newsl").addClass("isopen");
        });


        $('.click-newsletter2').click(function (e) {
            e.preventDefault();
            $(".news-open").slideToggle();
            $(".fixed-newsl").removeClass("isopen");
        });

    });

})(jQuery);
