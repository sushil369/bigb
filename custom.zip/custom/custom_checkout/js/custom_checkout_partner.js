(function($) {
    Drupal.behaviors.customer_payment = {
        attach: function(context, settings) {

            // Dhiren code
            var partner_status = Drupal.settings.custom_checkout.partner_status;
            //  console.log(partner_status);
            if (partner_status !== typeof undefined) {

                $("[id^='edit-pay']").keypress(function(event) {
                    if ((event.which != 46 || $(this).val().indexOf('.') != -1) &&
                            ((event.which < 48 || event.which > 57) &&
                                    (event.which != 0 && event.which != 8))) {
                        event.preventDefault();
                    }

                    var text = $(this).val();

                    if ((text.indexOf('.') != -1) &&
                            (text.substring(text.indexOf('.')).length > 2) &&
                            (event.which != 0 && event.which != 8) &&
                            ($(this)[0].selectionStart >= text.length - 2)) {
                        event.preventDefault();
                    }
                }); // end of keypress function 


                //Allow only numbers, dot, Tab and Backspace in 'Amount' textbox
                $("[id^='edit-pay']").keydown(function(e) {
                  var key;
                  var isShift;
                    if (window.event) {
                        key = window.event.keyCode;
                        isShift = !!window.event.shiftKey; // typecast to boolean
                    } else {
                        key = e.which;
                        isShift = !!e.shiftKey;
                    }
                  
                  
                    if (!((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || (e.keyCode == 8) || (e.keyCode == 9) || (e.keyCode == 110) || (e.keyCode == 190))) {
                       // if (e.keyCode < 48 || e.keyCode > 57) {
                        e.preventDefault();
                    }
                    else if((isShift)) {
                         e.preventDefault();
                    }
                });// end of keydown function
                

                show_hide_otp_fieldset();

                $('.oxigen-continue-to-pay').attr("disabled", "disabled");
                get_oxigen_html_order_summary();
                
                $('.oxigen-amt-input').blur(function() {
                    get_oxigen_html_order_summary();
                })

                $('.oxigen-region-fieldset').find('.form-checkbox').change(function() {                   
                    get_oxigen_html_order_summary();
                    show_hide_otp_fieldset();
                })
            }


            function show_hide_otp_fieldset() {
                if ($("input[name='pay_method[10]']").is(":checked") || $("input[name='pay_method[9]']").is(":checked")) {
                    $('#edit-customer-otp').show();
                }
                else {
                    $('#edit-customer-otp').hide();
                }
            }



            function get_oxigen_html_order_summary() {            
                var total_input_amt = 0;
                $('[class^="oxigen-balance-amt-"]').css("color", "#ccc"); // balance default color
                $('.oxigen-amt-input').each(function() {
                    var selected_field = $(this);
                    if (selected_field.closest('.oxigen-region-fieldset').find('.form-checkbox').is(":checked")) {

                        var this_vl = selected_field.val()
                        total_input_amt += Number(this_vl);

                        var checkbox_vl = selected_field.closest('.oxigen-region-fieldset').find('.form-checkbox').attr("value");
                        $('.oxigen-balance-amt-' + checkbox_vl).css("color", "#0000");
                    }

                });
                var total_order_amt = Drupal.settings.custom_checkout.total_order_amt;
                var to_be_paid_amt = Drupal.settings.custom_checkout.to_be_paid_amt;
                var remain_amt = Number(to_be_paid_amt) - Number(total_input_amt);
                if (remain_amt === 0) {
                    $('.oxigen-continue-to-pay').removeAttr("disabled", "disabled");
                }
                else {
                    $('.oxigen-continue-to-pay').attr("disabled", "disabled");
                }
                //console.log(remain_amt);
                //var imaginary_amt_remaining = Drupal.settings.custom_checkout.imaginary_amt_remaining;
                var show_remain_amt = remain_amt;
                if (remain_amt % 1 !== 0) {
                    show_remain_amt = remain_amt.toFixed(2);
                }
     
                var tmp = '<table><td class="calculation-label"><span class="cost-label">Order Amount:</span></td> <td class="calculation-data"><span class="c-amt"> Rs. </span><span class="c-amt-total">' + total_order_amt + '</span></td></tr><tr><td class="calculation-label"><span class="cost-label">Amount to Pay:</span></td> <td class="calculation-data"><span class="c-amt"> Rs. </span><span class="c-amt-total">' + to_be_paid_amt + '</span></td></tr><tr><td class="calculation-label balanceAmt"><span class="cost-label">Balance Amount:</span></td> <td class="calculation-data balanceAmt"><span class="c-amt"> Rs. </span><span class="c-amt-total">' + show_remain_amt + '</span></td></tr><tr></table>';
       
                $('.Oxigen-Order-summary').html(tmp);
            }

        }
    };
})(jQuery);
