(function($) {
    Drupal.behaviors.customer_payment = {
        attach: function(context, settings) {

            $('#edit-advance-account-pay, #edit-pay-at-franchisee-pay').keyup(function(e) {
                var amount = isNaN($(this).val()) ? 0 : $(this).val();
                $('.c-amt-wallet').text(amount);
                update_price_in_order_summary();
            });

            $('#edit-payback-burn-pay').keyup(function(e) {
                var amount = isNaN($(this).val()) ? 0 : $(this).val();
                $('.c-amt-payback').text(amount);
                update_price_in_order_summary();
            });

            //Allow only numbers, dot, Tab and Backspace in 'Amount' textbox
            $("#edit-advance-account-pay, #edit-payback-burn-pay, #edit-pay-at-franchisee-pay, [id^='edit-pay']").keydown(function(e) {
                //$("#edit-delivery").keydown(function(e) {
                if (!((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || (e.keyCode == 8) || (e.keyCode == 9) || (e.keyCode == 110) || (e.keyCode == 190))) {
                    //if (e.keyCode != 8 || e.keyCode == 189) {
                    e.preventDefault();
                    //}
                }
                //});
            });

            // Custom JS goes here.
            var egvList = $("body").find('.egv-list');
            if (egvList.find('li').length > 3) {
                egvList.css("height", "100px");
                egvList.css("overflow-y", "auto");
            }
            else {
                egvList.css("height", "auto");
                egvList.css("overflow-y", "");
            }


            function update_price_in_order_summary() {
                var remaining = parseInt($('.c-amt-total').text()) - (parseInt($('.c-amt-wallet').text()) + parseInt($('.c-amt-payback').text()));
                remaining = isNaN(remaining) ? 0 : remaining;
                $('.c-amt-remaining').text(parseInt(remaining));
            }

            //Change focus to next textbox for Card number field
            $("form input[placeholder=8888]").on('input', function() {
                $this = $(this);
                if ($this.val().length == $this.attr('maxlength')) {
                    $this.parent().next().find("input[placeholder=8888],input[placeholder=88]").focus();
                }
            });

//            $("body").find('#custom-checkout-full-payment-form .fieldset-title', context).on('click', function(e) {
//            $(this).parents('legend').siblings(".fieldset-wrapper").find('.form-checkbox').click();
//            $(this).parents('fieldset').siblings("fieldset").each(function() {
//                if (!$(this).hasClass('collapsed')) {
//                    $(this).find(".fieldset-wrapper").slideUp('slow').css("display", "none");
//                    $(this).addClass('collapsed').find(".fieldset-wrapper").find('.form-checkbox').click();
//                }
//            });
//        });

            //New UI radio buttons
            var paymentForm = $("body").find('[id^="custom-checkout-full-payment-form"]');
            var radioObj = paymentForm.find("input[name='pay_method']:checked");
            var radioVal = radioObj.val();
            radioObj.parent('.form-item-pay-method').siblings("fieldset[id^='edit-fieldset-title-" + radioVal + "']").show();

            paymentForm.find("input[type=radio][name='pay_method']").on('click', function(e) {
                var $this = $(this);

                var Val = $this.val();

                var showFieldset = $this.parent('.form-item-pay-method').siblings("fieldset[id^='edit-fieldset-title-" + Val + "']");

                var Fsets = $this.closest('[id^="payment-pane-wrapper-"]').siblings('[id^="payment-pane-wrapper-"]');

                $.each(Fsets, function() {
                    $(this).find('fieldset').slideUp();
                });

                //showFieldset.siblings('fieldset').slideUp();
                showFieldset.slideDown();

            });

        }
    };

//    $(document).ready(function() {
//        $('#custom-checkout-full-payment-form .fieldset-title').click(function(e) {
//            $(this).parents('legend').siblings(".fieldset-wrapper").find('.form-checkbox').click();
//            $(this).parents('fieldset').siblings("fieldset").each(function() {
//                if (!$(this).hasClass('collapsed')) {
//                    $(this).find(".fieldset-wrapper").slideUp('slow').css("display", "none");
//                    $(this).addClass('collapsed').find(".fieldset-wrapper").find('.form-checkbox').click();
//                }
//            });
//        });
//    });



})(jQuery);
