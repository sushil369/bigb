(function ($) {
    $(document).ready(function () {
        Drupal.behaviors.amount_autofill = {
            attach: function (context) {
                $(".field-name-commerce-product input.form-text").focusout(function () {
                    var this_var = $(this);
                    var sku = this_var.val();
                    if (!window.location.origin) {
                        var base_url_all = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');  //this code is for IE where window.location.origin is not work
                    } else {
                        var base_url_all = window.location.origin;
                    }
                    $.ajax({
                        type: "GET",
                        //url: location.origin + "/commerce/product/" + sku + "/autofill",
                        url: base_url_all + "/commerce/product/" + sku + "/autofill",
                        success: function (responce) {
                            //console.log(responce.amount);
                            this_var.parents(".field-name-commerce-product").siblings(".field-name-commerce-unit-price").find(".form-text").val(responce.amount);
                            this_var.parents(".field-name-commerce-product").siblings(".field-name-field-franchise-comission").find(".form-text").val(responce.commission);
                        },
                    });
                });
            }
        };
    });

})(jQuery);