(function ($) {
    jQuery(document).ready(function ($) {
        $('.cart-clicked-item').click(function (e) {
            $("#modalContent").addClass("add_to_cart_notification");
        });


    });

    jQuery(document).on('click', '.commerce-add-to-cart .form-submit', function (event) {
        if (jQuery(this).val() == 'Add to cart') {
            event.preventDefault();
            return false;
        }
    });

    jQuery(document).on('click', '#checkout-add-cart-form input', function (event) {
        var a = window.location.origin;
        if (!window.location.origin) {
            var base_url_all = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');  //this code is for IE where window.location.origin is not work
        } else {
            var base_url_all = window.location.origin;
        }
        var a = base_url_all;
        jQuery.ajax({
            type: "POST",
            dataType: 'html',
            cache: false, //for Chrome and IE8
            url: a + "/cart_product_count",
            success: function (response) {
                jQuery('.n-cart').replaceWith('<span class="n-cart">' + response + '</span>');
            },
            complete: function () {
                jQuery.ajax({
                    type: "POST",
                    dataType: 'html',
                    cache: false, //for Chrome and IE8
                    url: a + "/cart_hover_ajax",
                    data: {ajax: "ajax"},
                    success: function (response) {
                        jQuery('.cart_hover_outer_main').replaceWith(response);
                    },
                });
            },
        });

    });

})(jQuery);
