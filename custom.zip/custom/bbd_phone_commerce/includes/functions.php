<?php

module_load_include('inc', 'android_services', 'android_services');
module_load_include('inc', 'android_services', 'android_services_order');
module_load_include('module', 'android_services', 'android_services');
module_load_include('module', 'activity_log', 'activity_log');

/** Below are the DB Operation functions * */

/**
 * $uid - User id of which all orders to be fetched with order status -Phone Commerce Pending OR Phone Commerce Expire
 *
 *
 * */
function getall_uncompleted_orders($uid) {
  $query = db_select("commerce_order", "co");
  $query->fields("co", array("order_id"));
  $query->condition('co.uid', $uid);
  $query->condition('co.status', array('phone_commerce_pending', 'phone_commerce_expire'), 'IN');
  $output = $query->execute()->fetchALL();
  return $output;
}

function get_all_orders_of_phone($uid) {
  $query = db_select("commerce_order", "co");
  $query->fields("co", array("order_id"));
  $query->condition('co.uid', $uid);
  $query->condition('co.status', array('phone_commerce_processing', 'phone_commerce_cancel', 'processing'), 'IN');
  $output = $query->execute()->fetchALL();
  return $output;
}

/*
 *
 * $orderID is a object with "order_id" and "uid" value
 *
 */

function updateOrderStatus($orderID) {
  $order = commerce_order_load($orderID->order_id);
  if (!empty($order)) {
    $order->uid = $orderID->uid; // Move back all orders to their respective user created by CCA with pending state.
    $order->status = "phone_commerce_pending";
    commerce_order_save($order);
  }
}

/**
 *
 * Add Phone commerce record
 *
 * */
function addPhonerecord($fields) {
  db_insert('bbd_phone_commerce')
      ->fields($fields)
      ->execute();
}

/**
 *
 * Update Phone commerce record
 *
 * */
function updatePhonerecord($fields, $tid) {
  db_update('bbd_phone_commerce')
      ->fields($fields)
      ->condition('tid', $tid)
      ->execute();
}

/**
 *
 * This function is used to fetch all OrderIDs attended by call centre agent which are not yet pushed to tab.(Used for Previous order page)
 *
 * */
function getAllOrderIds($cca_id) {
  $query = db_select('bbd_phone_commerce', 'bpc');
  $query->fields('bpc', array('order_id'));
  $query->fields('bpc', array('uid'));
  $query->condition('bpc.cca_id', $cca_id);
  $query->condition('bpc.active', "1", "!=");
  $query->isNotNull('bpc.order_id');
  $orderIds = $query->execute()->fetchAll();
  return $orderIds;
}

function getOrderId_fromTransactID($tid) {
  $query = db_select('bbd_phone_commerce', 'bpc');
  $query->fields('bpc', array('order_id'));
  $query->condition('bpc.tid', $tid);
  $query->condition('bpc.active', "1", "!=");
  $query->isNotNull('bpc.order_id');
  $orderId = $query->execute()->fetchField();
  return $orderId;
}

/**
 *
 * $cca_id - Customer Care Agent ID
 * To fetch transaction ID which is handled by CCA for which the order ID is still not set or is set.
 * */
function getTransactionID($cca_id = NULL, $order_id = NULL) {
  $query = db_select('bbd_phone_commerce', 'bpc');
  $query->fields('bpc', array('tid'));
  if ($cca_id) {
    $query->condition('bpc.cca_id', $cca_id);
  }
  if ($order_id) {
    $query->condition('bpc.order_id', $order_id);
  }
  else {
    $query->isNull('bpc.order_id');
  }
  $tid = $query->execute()->fetchField();
  return $tid;
}

/**
 *
 * Get Transaction detail from Order ID
 *
 * */
function getTransactionDetail($order_id) {
  $query = db_select('bbd_phone_commerce', 'bpc');
  $query->fields('bpc', array('order_id', 'uid', 'franchisee_uid', 'field_phone_number_value', 'shipping_profile_id'));
  $query->condition('bpc.active', "1", "!=");
  $query->isNotNull('bpc.shipping_profile_id');
  $query->condition('bpc.order_id', $order_id);
  $transDetail = $query->execute()->fetchAll();
  return $transDetail;
}

function check_existing_customer($user_phone) {
  $query = db_select('users', 'U');
  $query->fields('U', array('uid'));
  $query->join('field_data_field_phone_number', 'FH', 'U.uid = FH.entity_id');
  $query->join('users_roles', 'UR', 'UR.uid=U.uid');
  $query->condition('FH.field_phone_number_value', $user_phone, '=');
  $query->condition('UR.rid', 7, '=');
  $exist_user_uid = $query->execute()->fetchField();
  return $exist_user_uid;
}

// End of DB operation functions

/** Below are the form building and operation functions * */

/**
 * $detailParams -- array which describes what needs to be displayed based on parameter.
 * 
 * */
function generateActionButtons($form, $form_state, $detailParams) { //$uid, $phoneNumber, $type, $tid=NULL, $buttonName, $forPrevOrderpage=0,$orderID=NULL) {
  $channel = bbd_common_get_channel();
  global $base_url;
  if (isset($_POST['user_id']) && isset($_POST['phone_number']) && isset($_POST['pin_code'])) {
    $_SESSION[$channel]['userID'] = $_POST['user_id'];
    $_SESSION[$channel]['phone_number'] = $_POST['phone_number'];
    $_SESSION[$channel]['franchisee_code'] = isset($_POST['franchisee_code']) ? $_POST['franchisee_code'] : NULL;
    $_SESSION[$channel]['pin_code'] = $_POST['pin_code'];
  }
  if ($detailParams['franchisee_code']) { // For customer prev order page since we don't get franchisee code directly
    $_SESSION[$channel]['franchisee_code'] = $detailParams['franchisee_code'];
  }
  if (isset($detailParams['prev_order_page']) && $detailParams['prev_order_page'] == 1 && ( $detailParams['buttonName'] == 'Browse Catalog' || $detailParams['buttonName'] == SELECT_PROCEED_BUTTON )) { // We want only Browse Catalog button on previous orders page, so we return html here.
    $form = array(
      '#method' => 'post',
      '#action' => '/' . BROWSE_CATALOG_PARAM . '/' . $_SESSION[$channel]['userID'] . '/' . $detailParams['type'],
      'phone_number' => array(
        '#type' => 'hidden',
        '#value' => $_SESSION[$channel]['phone_number'],
      ),
      'user_id' => array(
        '#type' => 'hidden',
        '#value' => $_SESSION[$channel]['userID'],
      ),
      'franchisee_code' => array(
        '#type' => 'hidden',
        '#value' => $_SESSION[$channel]['franchisee_code'],
      ),
      'type' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['type'],
      ),
      'order_id' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['orderID'],
      ),
      'uid' => array(
        '#type' => 'hidden',
        '#value' => $_SESSION[$channel]['userID'],
      ),
      'browse_submit' => array(
        '#type' => 'submit',
        '#value' => t($detailParams['buttonName']),
        '#submit' => '/' . BROWSE_CATALOG_PARAM . '/' . $detailParams['uid'] . '/' . $detailParams['type'],
      )
    );
    if ($detailParams['buttonName'] == SELECT_PROCEED_BUTTON) {
      $form['#action'] = "/" . SHIPPING_FRANCHISEE_URL;
    }
    return $form;
  }
  if ($detailParams['buttonName'] == 'Browse Catalog' || $detailParams['buttonName'] == SELECT_PROCEED_BUTTON) {
    $form = array(
      '#method' => 'post',
      '#action' => '/' . BROWSE_CATALOG_PARAM . '/' . $detailParams['uid'] . '/' . $detailParams['type'],
      'phone_number' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['phoneNumber'],
      ),
      'user_id' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['uid'],
      ),
      'transaction_id' => array(
        '#type' => 'hidden',
        '#value' => isset($detailParams['tid']) ? $detailParams['tid'] : "",
      ),
      'order_id' => array(
        '#type' => 'hidden',
        '#value' => isset($detailParams['orderID']) ? $detailParams['orderID'] : "",
      ),
      'franchisee_code' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['franchisee_code'],
      ),
      'pin_code' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['pin_code'],
      ),
      'browse_submit' => array(
        '#type' => 'submit',
        '#value' => t($detailParams['buttonName']),
      /* '#submit'       => '/'.BROWSE_CATALOG_PARAM.'/'.$detailParams['uid'].'/'.$detailParams['type'], */
      )
    );
    if ($detailParams['buttonName'] == SELECT_PROCEED_BUTTON) {
      if (isset($detailParams['tid'])) {
        $form['#action'] = '/' . BROWSE_CATALOG_PARAM . '/' . $detailParams['uid'] . '/' . $detailParams['type'];
      }
      else {
        $form['#action'] = "/" . SHIPPING_FRANCHISEE_URL;
      }
    }
    return $form;
  }

  $orders = getall_uncompleted_orders($detailParams['uid']);
  if (!empty($orders) && $detailParams['buttonName'] == "Previous Orders") {
    $form = array(
      '#method' => 'post',
      '#action' => '/' . PREVIOUS_ORDER_STRING_PATH . '/' . $detailParams['uid'] . '/' . $detailParams['type'],
      'phone_number' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['phoneNumber'],
      ),
      'user_id' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['uid'],
      ),
      'franchisee_code' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['franchisee_code'],
      ),
      'pin_code' => array(
        '#type' => 'hidden',
        '#value' => $detailParams['pin_code'],
      ),
      'prev_order_submit' => array(
        '#type' => 'submit',
        '#value' => t($detailParams['buttonName']),
      ),
    );

    return $form;
  }
  elseif ($detailParams['buttonName'] == "Previous Orders") {
    $form['#suffix'] = "<b> No Pending Previous Orders </b>";
    return $form;
  }

  $updatedOrders = get_all_orders_of_phone($detailParams['uid']);
  if (!empty($updatedOrders) && (count($updatedOrders) > 0) && $detailParams['buttonName'] == "Phone Orders") {
    $form = array(
      '#method' => 'post',
      '#action' => '/' . PREVIOUS_PHONE_ORDER_STRING_PATH . '/' . $detailParams['uid'] . '/' . $detailParams['type'],
      'prev_phone_order_submit' => array(
        '#type' => 'submit',
        '#value' => t($detailParams['buttonName']),
      ),
    );
    return $form;
  }
  else {
    $form['#suffix'] = "<b> No Phone Orders exist for this Contact </b>";
    return $form;
  }
}

function buildFranchiseeSelect_form($form, $form_state, $detailParams) {
  $channel = bbd_common_get_channel();
  if (isset($_POST['user_id']) && isset($_POST['phone_number']) && isset($_POST['pin_code'])) {
    $_SESSION[$channel]['userID'] = $_POST['user_id'];
    $_SESSION[$channel]['phone_number'] = $_POST['phone_number'];
    $_SESSION[$channel]['pin_code'] = $_POST['pin_code'];
  }

  $form = array(
    '#method' => 'post',
    '#action' => '/' . BROWSE_CATALOG_PARAM . '/' . $_SESSION[$channel]['userID'] . '/' . $detailParams['type'],
    'phone_number' => array(
      '#type' => 'hidden',
      '#value' => $_SESSION[$channel]['phone_number'],
    ),
    'user_id' => array(
      '#type' => 'hidden',
      '#value' => $_SESSION[$channel]['userID'],
    ),
    'franchisee_code' => array(
      '#type' => 'hidden',
      '#value' => $detailParams['franchisee_code'],
    ),
    'pin_code' => array(
      '#type' => 'hidden',
      '#value' => $_SESSION[$channel]['pin_code'],
    ),
    /* 'franchisee_code'   => array( */
    /*                              '#type'  => 'hidden',  */
    /*                              '#value' => $franchisee_code, */
    /*                              ), */
    'browse_submit' => array(
      '#type' => 'submit',
      '#value' => t(BROWSE_CATALOG_BUTTON),
    )
  );
  return $form;
}

function buildPrevattach_address_form($order_id) {
  $transDetail = getTransactionDetail($order_id);
  if (!empty($transDetail)) {
    foreach ($transDetail as $key => $value) {
      if ($value->shipping_profile_id) {
        $addressObj = commerce_customer_profile_load($value->shipping_profile_id);
        $userId = $value->uid;
        $franchiseeCode = get_franchisee_code_by_id($value->franchisee_uid);
        break;
      }
    }
    $user = user_load($userId);
    $html = '<b>Previous Attached address to this Order</b><table> 
            <tr>
              <th> Profile ID </th>
              <th> Shipping Address </th>
              <th> Uid </th>
              <th> Email </th>
              <th> Franchisee Code </th>
              <th> Phone Number </th>
              <th> Action </th>
            </tr>
            <tr>
              <td>' . $addressObj->profile_id . ' </td>
              <td>' . structurehtml($addressObj) . ' </td>
              <td>' . $userId . ' </td>
              <td>' . $user->mail . '</td>
              <td>' . $franchiseeCode . ' </td>
              <td>' . $addressObj->field_phone_number['und'][0]['value'] . '</td>
              <td>' . render(drupal_get_form('buildShippingAdd_form', $franchiseeCode, $addressObj->field_phone_number['und'][0]['value'], $addressObj->profile_id, $addressObj->profile_id, $user->mail, $userId)) . '</td>
            </tr>
          </table>';
    return $html;
  }
}

function buildShippingAdd_form($form, $form_state, $franchisee_code, $user_phone, $billing_address, $shipping_address, $email, $userID = NULL) {
  $channel = bbd_common_get_channel();
  if ($franchisee_code) {
    $_SESSION[$channel]['franchisee_code'] = $franchisee_code;
  }
  $userID = isset($userID) ? $userID : $_SESSION[$channel]['userID'];

  /* if($userID) { */
  /*   attachOrderShippingAddr($_SESSION[$channel]['order_id'],$franchisee_code,$userID,$user_phone,"phone_commerce_pending"); */
  /* } */
  $form = array(
    '#method' => 'post',
    '#action' => '/order/' . $_SESSION[$channel]['order_id'] . '/review/' . $userID,
    'franchisee_code' => array(
      '#type' => 'hidden',
      '#value' => $_SESSION[$channel]['franchisee_code'],
    ),
    'user_phone' => array(
      '#type' => 'hidden',
      '#value' => $user_phone,
    ),
    'billing_address' => array(
      '#type' => 'hidden',
      '#value' => $billing_address,
    ),
    'shipping_address' => array(
      '#type' => 'hidden',
      '#value' => $shipping_address,
    ),
    'email' => array(
      '#type' => 'hidden',
      '#value' => $email,
    ),
    'order_id' => array(
      '#type' => 'hidden',
      '#value' => $_SESSION[$channel]['order_id'],
    ),
    'user_id' => array(
      '#type' => 'hidden',
      '#value' => $userID,
    ),
    'select_proceed' => array(
      '#type' => 'submit',
      '#value' => t('Select & Proceed'),
    )
  );
  return $form;
}

function buildOrderReview_form() {
  $channel = bbd_common_get_channel();
  $shippingID = $_SESSION[$channel]['shipping_profile_id'] = $_POST['shipping_address'] ? $_POST['shipping_address'] : $_SESSION[$channel]['shipping_profile_id'];
  $billingID = $_SESSION[$channel]['billing_profile_id'] = $_POST['billing_address'] ? $_POST['billing_address'] : $_SESSION[$channel]['billing_profile_id'];
  $email = $_SESSION[$channel]['email'] = $_POST['email'] ? $_POST['email'] : $_SESSION[$channel]['email'];
  $phoneNo = $_SESSION[$channel]['phone_number'] = $_POST['user_phone'] ? $_POST['user_phone'] : $_SESSION[$channel]['phone_number'];
  $userID = $_SESSION[$channel]['userID'] = $_POST['user_id'] ? $_POST['user_id'] : $_SESSION[$channel]['userID'];

  $result = attachOrderShippingAddr($_SESSION[$channel]['order_id'], $_SESSION[$channel]['franchisee_code'], $userID, $phoneNo, "phone_commerce_pending", $shippingID);

  if ($result['status'] == "FAILURE") {
    drupal_set_message("error", "There was an error processing your order");
  }
  else {
    print render(drupal_get_form('order_review_form', $phoneNo, $billingID, $shippingID, $email, $result));
  }
}

function structurehtml($addressObj) {
  $html = $addressObj->commerce_customer_address['und'][0]['name_line'] . '<br/>
' . $addressObj->commerce_customer_address['und'][0]['thoroughfare'] . '<br/>';
  if ($addressObj->commerce_customer_address['und'][0]['premise']) {
    $html .= $addressObj->commerce_customer_address['und'][0]['premise'] . '<br/>';
  }
  $html .= $addressObj->commerce_customer_address['und'][0]['locality'] . ' ' . $addressObj->commerce_customer_address['und'][0]['administrative_area'] . ' ' . $addressObj->commerce_customer_address['und'][0]['postal_code'] . '<br/>
India<br/>';
  if ($addressObj->field_phone_number['und'][0]['value']) {
    $html .= '<b>Phone Number</b><br/>
' . $addressObj->field_phone_number['und'][0]['value'] . '<br/>';
  }
  return $html;
}

function order_review_form($form, &$form_state, $phoneNo, $billingID, $shippingID, $email, $result) {
  $channel = bbd_common_get_channel();
  $addressObj = commerce_customer_profile_load($shippingID);
  $user = user_load($addressObj->uid);
  $roles = user_roles();
  $rid = array_search('Customer', $roles);
  $changeAddressURL = "/" . SHIPPING_ADDRESS . "/" . $_SESSION[$channel]['userID'] . "/" . $_SESSION[$channel]['type'] . "/" . $_SESSION[$channel]['order_id'];

  if (array_key_exists($rid, $user->roles) && $_SESSION[$channel]['type'] == FRANCHISEE_TYPE) {
    $changeAddressURL = "/" . SHIPPING_CUSTOMER_URL;
  }
  $buildAddressHTML = structurehtml($addressObj);
  $userName = android_service_get_user_name_from_uid($addressObj->uid);
  //$url = "/" . SHIPPING_ADDRESS . "/" . $_SESSION[$channel]['userID'] . "/" . $_SESSION[$channel]['type'] . "/" . $_SESSION[$channel]['order_id'];
  /* if (strstr($_SERVER['HTTP_REFERER'], "?")) {
    $changeAddressURL = substr($_SERVER['HTTP_REFERER'], 0, strpos($_SERVER['HTTP_REFERER'], "?"));
    }
    else {
    $changeAddressURL = $_SERVER['HTTP_REFERER'];
    } */
  $changeAddressHTML = '<span><a href="' . $changeAddressURL . '">Change Address</a></span>';

  if ($_SESSION[$channel]['type'] == CUSTOMER_TYPE) {
    //Redirect to franchisee selection
    $franchisee_url = "/" . SHIPPING_FRANCHISEE_URL;
    $changeFranchiseeHTML = '<span><a href="' . $franchisee_url . '">Change Franchisee</a></span>';
  }

  $html = '<div class="account_info">
<b>Account Information</b><br/>
<div class="field-name">    
<span class="label">Username: </span><span class="field-content">' . $userName . '</span>  
</div>
<div class="field-email">    
<span class="label">E-mail address: </span><span class="field-content">' . $_SESSION[$channel]['email'] . '</span>  
</div>
           </div>

<div class="franchisee_info">
<b>Franchisee Information</b>
<div class="field-name">    
<span class="label">Franchisee name: </span><span class="field-content">' . $result['franchisee_user'] . '</span>  
</div>
<div class="field-email">    
<span class="label">E-mail address: </span><span class="field-content">' . $result['franchisee_mail'] . '</span>  
</div>
<div class="field-code">    
<span class="label">Franchisee Code: </span><span class="field-content">' . $_SESSION[$channel]['franchisee_code'] . '</span>  
</div>
<div class="field-phone">    
<span class="label">Phone No: </span><span class="field-content">' . $result['franchisee_phone'] . '</span>  
</div>
</div>

           <div class="billing_info">
<b>Billing Information</b> ' . $changeAddressHTML . '<br/>
' . $buildAddressHTML . '
          </div>

          <div class="shipping_info">
<b>Shipping Information</b><br/>
' . $buildAddressHTML . '
          </div><br/>';

  $form = array(
    '#method' => 'post',
    '#action' => '/order/' . $_SESSION[$channel]['order_id'] . '/complete',
    'order_id' => array(
      '#type' => 'hidden',
      '#value' => $_SESSION[$channel]['order_id'],
    ),
    'franchisee_code' => array(
      '#type' => 'hidden',
      '#value' => $_SESSION[$channel]['franchisee_code'],
    ),
    'user_id' => array(
      '#type' => 'hidden',
      '#value' => $_SESSION[$channel]['userID'],
    ),
    'user_phone' => array(
      '#type' => 'hidden',
      '#value' => $phoneNo,
    ),
    'billing_address' => array(
      '#type' => 'hidden',
      '#value' => $billingID,
    ),
    'shipping_address' => array(
      '#type' => 'hidden',
      '#value' => $shippingID,
    ),
    'email' => array(
      '#type' => 'hidden',
      '#value' => $email,
    ),
    'confirm' => array(
      '#prefix' => $html,
      '#type' => 'submit',
      '#value' => t('Confirm'),
    ),
  );

  return $form;
}

function buildOrderComplete_form() {
  $channel = bbd_common_get_channel();
  $order_id = $_SESSION[$channel]['order_id'];
  if (!empty($_POST)) {
    global $base_url;
    $bil['profile_id'] = $_POST['billing_address'];
    $ship['profile_id'] = $_POST['shipping_address'];

    $result = attachOrderShippingAddr($_POST['order_id'], $_POST['franchisee_code'], $_POST['user_id'], $_POST['user_phone'], "phone_commerce_processing", $_POST['shipping_address']);

    /* $result = android_services_checkout($_POST['order_id'], $_POST['franchisee_code'], $_POST['user_id'],$_POST['user_phone'] ,$bil, $ship, $_POST['email'],1);// This call will set order to phone commerce processing status */

    if ($result['status'] == "SUCCESS") {
      $franchisee_id = get_franchisee_id_by_code($_POST['franchisee_code']);
      updateBBDPhoneRecord($_POST['order_id'], $_POST['user_id'], $franchisee_id, $_POST['user_phone'], $_POST['shipping_address'], 1);
      /* $html = '<form id="commerce-checkout-form-complete" method="post" action="/order/' . $urlParams[1] . '/complete">
        <div>
        <div id="edit-checkout-completion-message" class="checkout_completion_message form-wrapper">
        <div class="checkout-completion-message">
        <p>Order number is ' . $_POST['order_id'] . '.This Order is now pushed to users tab</p>
        <p><a href="' . $base_url . '">Return to the front page.</a></p>
        </div>
        </div>
        </div>
        </form>';
       * 
       */
      $order = commerce_order_load($_SESSION[$channel]['order_id']);
      $amount = number_format(($order->commerce_order_total[LANGUAGE_NONE][0]['amount'] / 100), 2);

      // Customer Message
      if ($_SESSION[$channel]['type'] == CUSTOMER_TYPE) {
        $cust_mobile_num = $_SESSION[$channel]['phone_number'];
      }
      else {
        $address = commerce_customer_profile_load($_POST['shipping_address']);
        $cust_mobile_num = $address->field_phone_number[LANGUAGE_NONE][0]['value'];
      }
      $html = ' <div class="thank-you">
        	<h1 class="ty-txt">&nbsp;</h1>
	<div class="order-nmbr">
		<h1 class="order-txt">Order #' . $_POST['order_id'] . ' is complete</h1>
		<h2 class="order-txt">A Confirmation SMS has been sent to ' . $cust_mobile_num . '</h2>
		<p>You Should Receive The Confirmation SMS within the next 5 minutes<br>Haven t received The SMS yet? <a href="#">Resend SMS</a></p>
	</div>
</div>';
      return $html;
      $franchisee_name = user_load($franchisee_id)->name;
      $template_key = 'order_from_customer_support';
      $var = array('order_id' => $_SESSION[$channel]['order_id'],
        'amount' => $amount,
        'time' => variable_get('order-expire', 0),
        'pay_amount' => $amount,
        'franchisee' => $franchisee_name
      );
      sms_configuration_helper_for_sms_template($cust_mobile_num, $template_key, $var);

      // Franchisee Message
      if ($_SESSION[$channel]['type'] == FRANCHISEE_TYPE) {
        $franchisee_mobile_num = $_SESSION[$channel]['phone_number'];
      }
      else {
        $user = user_load($order->field_franchisee_uid[LANGUAGE_NONE][0]['uid']);
        $franchisee_mobile_num = $user->field_phone_number[LANGUAGE_NONE][0]['value'];
      }

      $cust_user = user_load($_POST['user_id']);
      $template_key = 'order_confirm_customer_support';
      $var = array('order_id' => $_SESSION[$channel]['order_id'],
        'name' => $cust_user->name,
        'time' => variable_get('order-expire', 0),
        'mobile_no' => isset($cust_mobile_num) ? $cust_mobile_num : $franchisee_mobile_num);
      sms_configuration_helper_for_sms_template($franchisee_mobile_num, $template_key, $var);

      if (isset($_SESSION[$channel]) && !empty($_SESSION[$channel])) {
        unset($_SESSION[$channel]);
      }
      return $html;
    }
  }
  else {
    $html = ' <div class="thank-you">
        	<h1 class="ty-txt">&nbsp;</h1>
	<div class="order-nmbr">
		<h1 class="order-txt">Order #' . $order_id . ' is complete</h1>
		<h2 class="order-txt">A Confirmation SMS has been sent to ' . $cust_mobile_num . '</h2>
		<p>You Should Receive The Confirmation SMS within the next 5 minutes<br>Haven t received The SMS yet? <a href="#">Resend SMS</a></p>
	</div>
</div>';
    return $html;
    // drupal_set_message("error", "There was an error processing your order");
  }
}

/**
 *
 * if $userCreate is empty then it is purely coming from search-customer page and CCA wants to create user from start point.
 *
 * */
function create_new_customer(&$form_state, $userCreate = NULL) {
  $channel = bbd_common_get_channel();
  $user_phone = $form_state['values']['field_phone_number'][LANGUAGE_NONE][0]['value'];
  $username = $form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0]['name_line'];
  $newUser = array(
    'name' => str_replace(' ', '_', $username) . '-' . $user_phone,
    'mail' => $user_phone . '@gmail.com',
    'status' => 1,
    'init' => $user_phone . '@gmail.com',
    'roles' => array(
      2 => 'authenticated user',
      7 => 'Customer',
    ),
    'field_user_billing_address' => array(LANGUAGE_NONE => array(0 => $form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0])),
    'field_phone_number' => array(LANGUAGE_NONE => array(0 => array("value" => $user_phone))),
  );

  $user = user_save(NULL, $newUser);

  $user_id = $user->uid;
  $_SESSION[$channel]['email'] = $user->mail;
  $_SESSION[$channel]['userID'] = $user_id;
  $_SESSION[$channel]['phone_number'] = $user_phone;

  $profile = commerce_customer_profile_new('shipping', $_SESSION[$channel]['userID']);
  $profile->commerce_customer_address = array(LANGUAGE_NONE => array(
      0 => addressfield_default_values(),
  ));
  $profile->uid = $_SESSION[$channel]['userID'];
  foreach ($form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0] as $addKey => $addValue) {
    $profile->commerce_customer_address[LANGUAGE_NONE][0][$addKey] = $form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0][$addKey];
  }
  $profile->field_phone_number[LANGUAGE_NONE][0]['value'] = $form_state['values']['field_phone_number'][LANGUAGE_NONE][0]['value'];
  $profile->field_neft_customer_email[LANGUAGE_NONE][0]['value'] = $form_state['values']['field_neft_customer_email'][LANGUAGE_NONE][0]['value'];
  commerce_customer_profile_save($profile);
  $_SESSION[$channel]['pin_code'] = $form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0]['postal_code'];
  if ($user_id) {
    return TRUE;
  }
  else {
    return FALSE;
  }
}

/**
 *
 * This function will create new shipping address for franchisee and will attach the same in the order object.
 * IF $userCreate is TRUE then it will create new user along with shipping detail.
 *
 * */
function addShippingaddress(&$form_state, $userCreate = NULL) {
  $channel = bbd_common_get_channel();
  if ($userCreate) {
    $user_phone = $form_state['values']['field_phone_number'][LANGUAGE_NONE][0]['value'];
    $exist_user_uid = check_existing_customer($user_phone);
    if ($exist_user_uid) {
      $existUser = user_load($exist_user_uid);
      $_SESSION[$channel]['email'] = $existUser->mail;
      $_SESSION[$channel]['userID'] = $exist_user_uid;
    }
    else {
      $username = $form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0]['name_line'];
      $newUser = array(
        'name' => str_replace(' ', '_', $username) . '-' . $user_phone,
        'mail' => $user_phone . '@gmail.com',
        'status' => 1,
        'init' => $user_phone . '@gmail.com',
        'roles' => array(
          2 => 'authenticated user',
          7 => 'Customer',
        ),
        'field_user_billing_address' => array(LANGUAGE_NONE => array(0 => $form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0])),
        'field_phone_number' => array(LANGUAGE_NONE => array(0 => array("value" => $user_phone))),
      );
      $user = user_save(NULL, $newUser);
      $user_id = $user->uid;
      $_SESSION[$channel]['email'] = $user->mail;
      $_SESSION[$channel]['userID'] = $user_id;
    }
  }

  if (isset($_SESSION[$channel]['userID'])) {
    $profile = commerce_customer_profile_new('shipping', $_SESSION[$channel]['userID']);
    $profile->commerce_customer_address = array(LANGUAGE_NONE => array(
        0 => addressfield_default_values(),
    ));
    $profile->uid = $_SESSION[$channel]['userID'];
    foreach ($form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0] as $addKey => $addValue) {
      $profile->commerce_customer_address[LANGUAGE_NONE][0][$addKey] = $form_state['values']['commerce_customer_address'][LANGUAGE_NONE][0][$addKey];
    }
    $profile->field_phone_number[LANGUAGE_NONE][0]['value'] = $form_state['values']['field_phone_number'][LANGUAGE_NONE][0]['value'];
    commerce_customer_profile_save($profile);

    $result = attachOrderShippingAddr($_SESSION[$channel]['order_id'], $_SESSION[$channel]['franchisee_code'], $_SESSION[$channel]['userID'], $form_state['values']['field_phone_number'][LANGUAGE_NONE][0]['value'], "phone_commerce_pending", $profile->profile_id);

    if ($result['status'] == "FAILURE") {
      drupal_set_message("error", "There was an error processing your order");
    }
    else {
      $_SESSION[$channel]['phone_number'] = $form_state['values']['field_phone_number'][LANGUAGE_NONE][0]['value'];
      $_SESSION[$channel]['billing_profile_id'] = $profile->profile_id;
      $_SESSION[$channel]['shipping_profile_id'] = $profile->profile_id;
      drupal_goto("order/" . $_SESSION[$channel]['order_id'] . "/review/" . $_SESSION[$channel]['userID']);
    }
  }
}

/**
 *
 * $orderID       - Order ID
 * $franchiseeCode - Franchisee Code
 * $userID         - User ID for which order is been created
 * $phoneNo        - Phone No. of user for which order is been created
 * $addressID      - For now we ar considering shiiping address id and billing id same for the user for which order is been created
  - If NULL then it will only update status of the order(Which is used when CCA lands on Shipping Selection page)
 * $status         - Status to which order needs to be updated.
 *
 * */
function attachOrderShippingAddr($orderID, $franchiseeCode, $userID, $phoneNo, $status, $addressID = NULL) {
  $order = commerce_order_load($orderID);
  $order->uid = $userID;
  $franchisee_id = get_franchisee_id_by_code($franchiseeCode);
  $franchiseeUser = user_load($franchisee_id);
  $order->field_franchisee_uid[LANGUAGE_NONE][0]['uid'] = $franchisee_id;
  if ($addressID) {
    $order->commerce_customer_billing[LANGUAGE_NONE][0]['profile_id'] = $addressID;
    $order->commerce_customer_shipping[LANGUAGE_NONE][0]['profile_id'] = $addressID;
  }
  $order->status = $status;
  $result = commerce_order_save($order);
  if ($result) {
    $resultDetail['franchisee_user'] = $franchiseeUser->name;
    $resultDetail['franchisee_mail'] = $franchiseeUser->mail;
    $resultDetail['franchisee_phone'] = $franchiseeUser->field_phone_number['und'][0]['value'];
    $resultDetail['status'] = "SUCCESS";
    //** Updated phone record in bbd phone commerce table**//
    updateBBDPhoneRecord($orderID, $userID, $franchisee_id, $phoneNo, $addressID);
    if ($status == 'phone_commerce_processing') {
      order_status_attach_all_line_status($order->order_id, 'awaiting_payment', time());
    }
    return $resultDetail;
    /* return $result['status'] = "SUCCESS"; */
  }
  else {
    return $resultDetail['status'] = "FAILURE";
  }
}

/**
 *
 * This function will updated BBD phone commerce record w.r.t franchiseeID,userID for which order is created and the status of that phone order()
 * $pushtoTab :Default 0 i.e the order is still in process to be pushed to tab while 1 means the order is now pushed to users tab.
 *
 * */
function updateBBDPhoneRecord($orderID, $userID, $franchisee_id, $phoneNo, $shipping_profile_id, $pushtoTab = 0) {
  global $user;
  $tid = getTransactionID($user->uid, $orderID);
  if ($tid && $orderID && $userID && $franchisee_id && $phoneNo) {
    $fields = array(
      'uid' => $userID,
      'franchisee_uid' => $franchisee_id,
      'field_phone_number_value' => $phoneNo,
      'shipping_profile_id' => $shipping_profile_id,
      'active' => $pushtoTab,
    );
    updatePhonerecord($fields, $tid);
  }
}

function get_city_from_pin_code() {
  $query = db_select('pin_code', 'pc');
  $query->fields('pc', array('district'));
  $query->distinct();
  $query->orderBy('pc.district');
  $result = $query->execute()->fetchCol();
  if (!empty($result)) {
    $data = array(" " => "Select");
    foreach ($result as $key => $value) {
      $data[$value] = $value;
    }
  }
  return $data;
}

function get_state_from_pin_code() {
  $query = db_select('pin_code', 'pc');
  $query->fields('pc', array('state'));
  $query->distinct();
  $query->orderBy('pc.state');
  $result = $query->execute()->fetchCol();
  if (!empty($result)) {
    $data = array(" " => "Select");
    foreach ($result as $key => $value) {
      $data[$value] = $value;
    }
  }
  return $data;
}
