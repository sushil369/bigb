/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//(function ($) {
//    Drupal.behaviors.example_name = {
//        attach: function(context) {
//            alert("test");
//            alert(Drupal.settings.my_var);
//        }
//    }
//})(jQuery);


(function($) {
  Drupal.behaviors.MODULENAME = {
    attach: function (context, settings) {
     
    $("#slider-range").slider({
			range: true,
			min: 1,
			max: 5000,
			values: [settings.slider.min, settings.slider.max],
			step: 1,
			slide: function(event, ui) {
				$("#amount-min").val(ui.values[0]);
				$("#amount-max").val(ui.values[1]);
			}
		});
         $("#amount-min").val($("#slider-range").slider("values", 0));
	 $("#amount-max").val($("#slider-range").slider("values", 1));
    
    }
  };

})(jQuery);


	
		
       
