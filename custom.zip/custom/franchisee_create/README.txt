***********
* README: *
***********

DESCRIPTION:
------------
This module is used to import users having role 'franchisee' with and without partner name and category.


INSTALLATION:
-------------
1. Place the entire email directory into your Drupal sites/all/modules/custom
   directory.

2. Enable the email module by navigating to:

     administer > modules


Features:
---------
  * validation of fields as per required format.
  * validation of mapping of partner category to partner name.
  * dynamic help text generated.

Note:
-----
1. To import users without partner name and category the url is : $base_url . '/import/create_bbd_franchisee'
2. To import users with partner name and the url is : $base_url . '/import/create_partner_agent'


Author:
-------
Ritesh Manek
ritesh.manek@iksula.com
riteshmanek1992@gmail.com
