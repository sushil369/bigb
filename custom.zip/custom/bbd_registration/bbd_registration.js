jQuery(document).ready(function($) {
    $.noConflict();
     if ($(window).width() > 736) {
        /* $('.h-menu.login').on('click', function() {
            $('.login-h-outer').slideToggle("300");
        });
        $('.h-menu.login.logout').on('click', function() {
            $('.after-login-h-outer').slideToggle("300");
        }); */
		$(document).on("click", '.h-menu.login', function(event) {
		   $('.login-h-outer').slideToggle("300");
		});
		$(document).on("click", '.h-menu.login.logout', function(event) {
		   $('.after-login-h-outer').slideToggle("300");
		});		
    }
    $("#mobile-logout").click(function(e) {
        e.preventDefault();
        $(".account-dropdown").slideToggle(500);
    });

    if ($("#h-menutrack-order").length > 0) {
        $("#h-menutrack-order").colorbox({inline: true, width: "50%", href: "#login-h-track", className: 'track-order-popup',
            onClosed: function() {
                // open the other colorBox
                $('#colorbox').removeClass('track-order-popup');
            }
        });
    }

    $(".order_st_submit").click(function(e) {
        if ($('.email_tr').val().length == 0) {
            e.preventDefault();
            $('.email_tr').addClass('error');
        }
        if (!validateEmail($('.email_tr').val())) {
            e.preventDefault();
            $('.orderid_tr').addClass('error');
        }
        if ($('.orderid_tr').val().length == 0) {
            e.preventDefault();
            $('.orderid_tr').addClass('error');
        }

    });
    $(".formlogin_track").click(function(e) {
        if ($('.track-order-popup .name_tr').val().length == 0) {
            e.preventDefault();
            $('.name_tr').addClass('error');
        }
        if ($('.track-order-popup .pass_tr').val().length == 0) {
            e.preventDefault();
            $('.pass_tr').addClass('error');
        }

    });
    function validateEmail($email) {
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        if (!emailReg.test($email)) {
            return false;
        } else {
            return true;
        }
    }
    if ($(window).width() <= 768 && $('body').hasClass('page-register')) {
        $('.wrapper-in #content .title').prepend('<span class="previous-page"><a href="" onClick="history.go(-1);"></a></span>');
    }

    $('.previous-page').click(function() {
    });
});