jQuery(document).ready(function () {
    jQuery('#edit-commerce-payment-payment-method-commerce-franchiseecommerce-payment-commerce-franchisee').click(function () {
        jQuery('.we-accept-wrap').hide();
    });
    jQuery('#edit-commerce-payment-payment-method-commerce-icici-paymentcommerce-payment-commerce-icici-payment').click(function () {
        jQuery('.we-accept-wrap').show();
    });
});