(function ($) {
    Drupal.behaviors.addToCompare = {
        attach: function (context, settings) {
            $(document).ready(function () {
                $(document).ajaxComplete(function () {
                    attach_events_to_element();
                });
                attach_events_to_element();
            });
            function attach_events_to_element() {
                jQuery(document).on('click', '#remove-id', function (event) {
                    jQuery('.message').remove();
                    var div_len = jQuery("#block-bbd-compare-product-popup .content #product-popup .compare-common-id:visible").length;
                    if (div_len == 0) {
                        jQuery('#block-bbd-compare-product-popup').hide();
                        window.location.reload();
                    }
                    var that = this;
                    var nid = jQuery(this).attr('class').split('-_-')[0];
                    var tid = jQuery(this).attr('class').split('-_-')[1];
                    var ssid = jQuery(this).attr('class').split('-_-')[2];
                    var uid = jQuery(this).attr('class').split('-_-')[3];
                    var url = Drupal.settings.basePath + 'product_compare_ajax';
                    jQuery.post(url, {'nid': nid, 'tid': tid, 'ssid': ssid, 'uid': uid},
                    function (data) {
                        if (data) {
                            jQuery('.compare-message').html('Atleast 2 Products required for comparision');
                            //window.location.href = '/taxonomy/term/' + tid;
                            window.location.reload();
                        }
                        jQuery('.compare-message').html(data);
                        event.preventDefault();
                        jQuery('.compare-' + nid).attr('checked', false);
                        jQuery.post(Drupal.settings.basePath + 'compare_ajax',
                                function (data) {
                                    jQuery('#product-popup').html(data);
                                });
                        event.preventDefault();

                        jQuery(that).parent("div").hide();
                        event.preventDefault();
                        var div_len = jQuery("#block-bbd-compare-product-popup .content #product-popup .compare-common-id:visible").length;
                        if (div_len == 0) {
                            jQuery('#block-bbd-compare-product-popup').hide();
                            window.location.reload();
                        }
                        if (div_len < 1) {
                            jQuery('#compare-link-category-popup').hide();
                        }
                        /*to hide compare block if no product to compare exists*/
                        if (div_len == 2) {
                            var last_div = jQuery("#block-bbd-compare-product-popup .content #product-popup div.compare-common-id #remove-id").click(function () {
                                jQuery('#block-bbd-compare-product-popup').hide();
                            });
                        }
                    });
                    event.preventDefault();
                });

                jQuery('.add-to-compare:not(.add-clicked)').click(function () {
                    var nid = jQuery(this).attr('allval').split('-_-')[0];
                    var uid = jQuery(this).attr('allval').split('-_-')[1];
                    var tid = jQuery(this).attr('allval').split('-_-')[2];
                    var ssid = jQuery(this).attr('allval').split('-_-')[3];
                    var div_len = jQuery("#block-bbd-compare-product-popup .content #product-popup .compare-common-id:visible").length;
                    if (this.checked) {
                        if (div_len == 4) {
                            alert('Maximum 4 Products are added for comparison');
                            return false;
                        } else {
                            jQuery('.compare-' + nid).attr('checked', true);
                            var url = Drupal.settings.basePath + 'insert_compare_ajax';
                        }

                    } else {
                        jQuery('.compare-' + nid).attr('checked', false);
                        var url = Drupal.settings.basePath + 'product_compare_ajax';
                    }
                    jQuery.post(url, {'nid': nid, 'tid': tid, 'ssid': ssid, 'uid': uid},
                    function (data) {
                        if (jQuery('#product-popup').length == 0) {
                            window.location.reload();
                        }
                        jQuery.post(Drupal.settings.basePath + 'compare_ajax', {'tid': tid},
                        function (data) {
                            if (data.length > 0) {
                                jQuery('#product-popup').html(data);
                            }
                            else {
                                window.location.reload();
                            }
                        });
                    });
                }).addClass('add-clicked');

                jQuery(document).on('click', '#close', function (event) {
                    var uid = jQuery(this).attr('class').split('-_-')[0];
                    var tid = jQuery(this).attr('class').split('-_-')[1];
                    var ssid = jQuery(this).attr('class').split('-_-')[2];
                    var url = Drupal.settings.basePath + 'product_compare_remove_panel_ajax';
                    jQuery.post(url, {'tid': tid, 'ssid': ssid, 'uid': uid},
                    function (data) {
                        window.location.reload();
                    });
                });
            }
        }
    };
})(jQuery);