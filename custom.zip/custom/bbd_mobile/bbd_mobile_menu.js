(function ($) {
    Drupal.behaviors.mobilemenu = {
        attach: function (context, settings) {
//    $('.second_third_level_ul').hide();
//    $('li').click(function(){
//        $(this).find("ul.second_third_level_ul").toggle();
//    });   
            $('#menu').slicknav();
        }
    };
})(jQuery);
