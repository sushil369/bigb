jQuery(document).ready(function ($) {
    $('.filter_block').hide();
    $('#filter').click(function () {
        $('.filter_block').slideToggle();
    });

    $('.filter_block > form > div').accordion({
        header: 'label:not(.option)'
    });
});

