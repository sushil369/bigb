(function ($) {
    $(document).ready(function () {

//        $('.slideshow').cycle({
//            fx: 'scrollHorz',
//            speed: 500,
//            timeout: 0,
//            prev: '#prev',
//            next: '#next'
// 
//            });
        var total = $(".slideshow img").length;
        if (total != 1) {
            $(".slideshow").slick({
                infinite: true,
                speed: 500,
                arrows: true,
                //slide:'img',
            });
        }

        $('.pdesc-title').click(function () {
            $(this).toggleClass('collapsed');
            $(this).next('div').slideToggle();
        });


    });

})(jQuery);






       