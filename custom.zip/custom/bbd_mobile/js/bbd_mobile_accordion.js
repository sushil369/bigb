(function ($) {
    $(document).ready(function () {

        function getQueryValue(value) {
            var query = window.location.search.substring(1);
            var vars = query.split('&');
            for (var i = 0; i < vars.length; i++) {
                var name = vars[i].split('=');
                if (name[0] == value) {
                    return (name[1]);
                }
            }
            return 0;
        }

        var panel = parseInt(getQueryValue('panel'));

        $('#accordion').accordion({collapsible: true, active: panel});
        $('.accordion').accordion({collapsible: true, active: 0});

    });

})(jQuery);