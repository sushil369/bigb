
Drupal.behaviors.hide_confirm_myaccount_mobile = {
    attach: function (context) {
        // jQuery("input[id*='edit-myselector']").on("click", function(e)  {
        // jQuery(".hide_confirm").show();
        //});
        jQuery(".form-checkbox").change(function () {

            var count_checked = jQuery("input[id*='edit-myselector']:checked").length;
            if (count_checked > 0) {
                jQuery(".hide_confirm").show();
            } else {
                jQuery(".hide_confirm").hide();
            }

        });

        jQuery(".select-all").change(function () {
            setTimeout(function () {
                var count_checked = jQuery("input[id*='edit-myselector']:checked").length;
                if (count_checked > 0) {
                    jQuery(".hide_confirm").show();
                } else {
                    jQuery(".hide_confirm").hide();
                }
            }, 1000);
        });
    }

};

Drupal.behaviors.view_items_in_order = {
    attach: function (context) {
        jQuery('#edit-search').focus(function () {
            jQuery(this).val('');
        });
        jQuery('.view-item-order').click(function (e) {
            e.preventDefault();
            var order_id = jQuery(this).attr('id');
            jQuery("#linedetail" + order_id).slideToggle();
        });
    }
};