Drupal.behaviors.product_compare = {
    attach: function (context, settings) {
        jQuery('.comp-show', context).click(function () {
            jQuery("#block-bbd-compare-product-compare-products").show(); // show compare block on click on add to compare check box
            var id = jQuery(this).attr('id');
            var pro_sku = jQuery(this).attr('data-sku');
            var pro_title = jQuery(this).attr('data-title');
            var pro_cat = jQuery(this).attr('data-unqueid');
            var pro_id = jQuery(this).attr('data-pid');
            var n_id = jQuery(this).attr('data-nid');
            var pro_key = n_id + "_" + pro_id;
            
            if (jQuery("#" + id).is(":checked")) {
                // checkbox is checked add this into compare block
//                console.log("check is check");
                var exist_tray_cat = jQuery("#unique_id").val();
                if (exist_tray_cat !== typeof undefined && exist_tray_cat !== "" && exist_tray_cat != 0) {
                    //then compare whether added product belong to same tray category
                    if (exist_tray_cat != pro_cat && pro_cat !== "") {
//                        jQuery(".compare-err-msg-holder").html("Cant compare products from 2 different categories").show();
                        //first remove all html 
//                        jQuery(".compare-items").empty();
//                        //add empty html
//                        var empty_html = '<div class="compare-item empty_item"><div class="thumb_holder"></div><div class="description"></div><div class="product_mrp"></div><span class="delete" title="Remove"></span></div>';
//                        empty_html += '<div class="compare-item empty_item"><div class="thumb_holder"></div><div class="description"></div><div class="product_mrp"></div><span class="delete" title="Remove"></span></div>';
//                        empty_html += '<div class="compare-item empty_item"><div class="thumb_holder"></div><div class="description"></div><div class="product_mrp"></div><span class="delete" title="Remove"></span></div>';
//                        empty_html += '<div class="compare-item empty_item"><div class="thumb_holder"></div><div class="description"></div><div class="product_mrp"></div><span class="delete" title="Remove"></span></div>';
//      
//                        jQuery(".compare-items").append(empty_html);
//                        return false;
//                        console.log("Cant compare products from 2 different categories");
                        jQuery("div .compare-item").each(function (index, element) {
                            var $this = jQuery(this);
                            var current_item_id = $this.attr('item_id');
                            if (typeof current_item_id !== typeof undefined && current_item_id !== false) {
                                var title = jQuery("div .description");
                                var img = jQuery("div .thumb_holder ");
                                var mrp = jQuery("div .product_mrp");
                                $this.find(img).html("");
                                $this.find(title).html("");
                                $this.find(mrp).html("");
                                $this.removeAttr("item_id");
                                $this.addClass("empty_item");
                            }


                        });
                    }
                }//else dont compare the added product with tray category

                var i = 0;
                jQuery("div .empty_item").each(function (index, element) {
                    i++;
                    var $this = jQuery(this);
                    var tmp = $this.attr('item_id');
                    if (tmp === undefined || tmp == '') {
                        // item id not exist so add the checked product using ajax in tray
                        $this.removeClass("empty_item");
                        $this.addClass("req_item");
                        $this.attr("item_id", pro_key);
                        var current_plp_page_url = window.location.href;
                        var response = add_product_into_session(pro_sku, pro_cat, pro_id, n_id, "plp", current_plp_page_url);
                        
                        var current_item_id  = jQuery("div .req_item").attr('item_id');

//                        console.log("Total added item --" + response['product_count']);
                        if (typeof response['tid'] !== typeof undefined && response['tid'] !== false) {
//                                    console.log("add term id in hidden field of tray");
                            jQuery("#unique_id").val(response['tid']);
                        }
                        
                        if (typeof current_item_id !== typeof undefined && current_item_id !== false && current_item_id == response['nid'] + "_" + response['pid']) {
                            // add product details in compare block
                            var title = jQuery("div .description");
                            var img = jQuery("div .thumb_holder");
                            var mrp = jQuery("div .product_mrp");
                            var $this = jQuery("div .req_item");
                            $this.find(img).html(response['img_url']);
                            $this.find(title).html(response['title']);
                            $this.find(mrp).html(response['amount']);
                            $this.removeClass("req_item");// remove once added in compare tray
                            jQuery( "#checkbox" + response['pid'] ).parent().parent().addClass('active');// add active class div.bbd-product on plp page
                        }
                        else {
                            jQuery("#checkbox" + response['pid']).attr('checked', false);
                            //uncheked the checkedbox while failed to adding product to compare section 
                            var $error_msg = "Something went wrong while adding product to tray";
                            show_error($error_msg);
                            window.location.reload(1);// in case of failure, refresh current page
//                            jQuery(".compare-err-msg-holder").html("Something went wrong while adding product to tray").show().delay(5000).fadeOut();
//                                    console.log("Something went wrong while adding product to tray");
                        }
                        if(typeof response['page_refresh'] !== typeof undefined && response['page_refresh'] === "Yes" && response['category_switch'] != "Yes"){
                            window.location.reload(1);// in case of total added product in add to compare block is different than exist product session
                        }
                        //now check if category switch, remove existing one 
                        if(typeof response['category_switch'] !== typeof undefined && response['category_switch'] === "Yes"){
                            //category is switch so remove previously added product
                            
//                            console.log("category switched...");
                            if (response['previous_compare_products'] !== typeof undefined && response['previous_compare_products'] !== "" ) {
//                                console.log("Show Previous compare block");
                                var site_url = window.location.origin;
                                var pre_pro_list = response['previous_compare_products'];
//                                var pre_block_html = "<a target='_blank' href='/compare-product/previous/?ids="+pre_pro_list+"' class='pre-comp-url' onclick='setTimeout(function () {window.location.reload(1);}, 3000);'>Your Last Compare</a>";
                                var pre_block_html = "<a target='_blank' href='/compare-product/previous/?ids="+pre_pro_list+"' class='pre-comp-url' onclick='jQuery(\"#last_compare_click\").val(1);'>Your Last Compare</a>";
                                var $this = jQuery("#previous-compare-products");
                                $this.html(pre_block_html);
                                $this.removeClass("hide-pre-tab");
                                $this.addClass("show-pre-tab");
                                jQuery("#block-bbd-compare-product-previous-compare-products").show();
                            }
                            else{
//                                console.log("Hide Previous compare block");
                                var $this = jQuery("#previous-compare-products");
                                $this.html("");
                                $this.addClass("hide-pre-tab");
                                $this.removeClass("show-pre-tab");
                                jQuery("#block-bbd-compare-product-previous-compare-products").hide();
                            }
                        }
                        else{
//                            console.log("category Not ....switched...");
                        }
                        
                        //add or remove disabled class to compare button depend on product_count
                        if (response['product_count'] >= 2) {
                            // when 2 or more than 2 product in compare tray enable compare button
                            jQuery(".compare-button").removeClass("disabled");
                        }
                        else {
                            // when product in compare tray is less than 2 , disable the compare button
                            jQuery(".compare-button").addClass("disabled");
                        }
//                        console.log("before break;");
                        return false; // break the each loop once find empty compare tary item
                    }
                    else if (tmp !== undefined && tmp != '') {
//                        alert("Product allready exists in Compare Tray");
                        var $error_msg = "Product already exists in Compare Tray";
                        show_error($error_msg);
//                        jQuery(".compare-err-msg-holder").html("Product already exists in Compare Tray").show().delay(5000).fadeOut();
                    }

                });
                if (i == 0) {
                    var $error_msg = "You can compare maximum 4 products at a time.";
                    show_error($error_msg);
                    
                    var exist_tray_cat = jQuery("#unique_id").val();
                    if (exist_tray_cat !== typeof undefined && exist_tray_cat !== "" && exist_tray_cat != 0) {
                        //then compare whether added product belong to same tray category
                        if (exist_tray_cat != pro_cat) {
                            var $error_msg = "Cannot compare products from 2 different categories";
                            show_error($error_msg);
//                            jQuery(".compare-err-msg-holder").html("Cannot compare products from 2 different categories").show().delay(5000).fadeOut();
                            return false;
//                        console.log("Cant compare products from 2 different categories");
                        }
                    }
                    return false;// dont allow to check once tray is full
                }
            }//end of if
            else {
                // checkbox is un-checked remove from this into compare block
//                console.log("un check");
                var i = 0;
                jQuery("div .compare-item").each(function (index, element) {
                    var tmp = jQuery(this).attr('item_id');
                    if (tmp == pro_key) {
//                        console.log("get remove product" + pro_sku);
                        //call fuction to remove product from session
                        var response = remove_product_from_session(pro_id, n_id, pro_cat, "single");// single parameter to remove single product
                        
                        if (response['tid'] !== typeof undefined && response['tid'] !== "" && response['tid'] === 0) {
                            // add 0 value to input id = unique_id 
                            // while inserting first product after removing all product.
                            //we make 0, so it will skip validation of term id for first product
                            jQuery("#unique_id").val(0);
                        }
                        if (response['product_count'] >= 2) {
                            // when 2 or more than 2 product in compare tray enable compare button
                            jQuery(".compare-button").removeClass("disabled");
                        }
                        else {
                            // when product in compare tray is less than 2 , disable the compare button
                            jQuery(".compare-button").addClass("disabled");
                        }
                        if (response['status'] === "1111") {
                            //product successfully remove from session
                            //now remove html from compare tray section
                            jQuery("div .compare-item").each(function (index, element) {
                                var $this = jQuery(this);
                                var current_item_id = $this.attr('item_id');
                                if (typeof current_item_id !== typeof undefined && current_item_id !== false && current_item_id == pro_key) {
//                                            console.log("find item in tray"+tmp);
                                    var title = jQuery("div .description");
                                    var img = jQuery("div .thumb_holder ");
                                    var mrp = jQuery("div .product_mrp");
                                    $this.find(img).html("");
                                    $this.find(title).html("");
                                    $this.find(mrp).html("");
                                    $this.removeAttr("item_id");
                                    $this.addClass("empty_item");
                                    jQuery( "#checkbox" + response['pid'] ).parent().parent().removeClass('active');// remove active class div.bbd-product on plp page
                                    return false; // break the each loop once find pro. in compare tray.
                                }


                            });

                        }
                        else if (response['status'] === "0000") {
                            // geting some error
                            var $error_msg = "Oops! Something goes wrong..while removing product from compare tray";
//                            show_error($error_msg);
                            window.location.reload(1);// in case of failure, refresh current page
//                            jQuery(".compare-err-msg-holder").html("Oops! Something goes wrong..while removing product from compare tray").show().delay(5000).fadeOut();
//                                    console.log("Oops! Something goes wrong..");
                        }
                        return false; // break the each loop once find resp. compare tray item
                    }
                    else {
//                        compare jQuery(".compare-err-msg-holder").html("Not finding product").show().delay(5000).fadeOut();
//                        console.log("Not finding product");
                    }

                });
            }//end of else
        });
        
        //remove product on click on cross image on single product in compare tray
        jQuery('.delete', context).click(function () {
            var $this = jQuery(this);
            var parent_item_id = $this.parent().attr('item_id');
            var pro_cat = jQuery("#unique_id").val();
            var tmp = parent_item_id.split("_");
            var nid = tmp[0];
            var pid = tmp[1];
//            console.log("click single product close");
            var response = remove_product_from_session(pid, nid, pro_cat, "single");// single parameter to remove single product
            
            if (response['tid'] !== typeof undefined && response['tid'] !== "" && response['tid'] === 0) {
                // add 0 value to input id = unique_id 
                // while inserting first product after removing all product.
                //we make 0, so it will skip validation of term id for first product
                jQuery("#unique_id").val(0);
            }
            if (response['product_count'] >= 2) {
                // when 2 or more than 2 product in compare tray enable compare button
                jQuery(".compare-button").removeClass("disabled");
            }
            else {
                // when product in compare tray is less than 2 , disable the compare button
                jQuery(".compare-button").addClass("disabled");
            }
            if (response['status'] === "1111") {
                //product successfully remove from session
                //now remove html from compare tray section
                $this.siblings("div .thumb_holder").empty();
                $this.siblings("div .description").empty();
                $this.siblings("div .product_mrp").empty();
                $this.parent().removeAttr('item_id');
                $this.parent().addClass("empty_item");
                //now uncheck and remove active class in plp page
                jQuery( "#checkbox" + response['pid'] ).attr('checked', false);
                jQuery( "#checkbox" + response['pid'] ).parent().parent().removeClass('active');
                //now remove disable class on pdp page anchor link on pdp page
                //in case same product remove on it pdp page
                var pdp_pro_pid = jQuery("#comp-button").attr('data-pid');
                if(pdp_pro_pid == response['pid']){
//                    console.log("remove disable class from pdp");
                    jQuery("#comp-button").removeClass("disabled");
                }//else do nothing....
                
            }
            else if (response['status'] === "0000") {
                // geting some error
                var $error_msg = "Oops! Something goes wrong..while removing product from compare tray";
//                show_error($error_msg);
                window.location.reload(1);// in case of failure, refresh current page
//                jQuery(".compare-err-msg-holder").html("Oops! Something goes wrong..while removing product from compare tray").show().delay(5000).fadeOut();
            }
            
        });
        
        //remove all product click on close image on compare tray
        jQuery('.close-tray', context).click(function () {
            //first hide compare tray
            jQuery("#block-bbd-compare-product-compare-products").hide();
//            console.log("close and emty entire tray");
            // all parameter to remove all product from addtocompare session
            // pass empty nid and pid to ajax,bcz we empty all current session
            // pass term id of current comparare products 
            var pro_cat = jQuery("#unique_id").val();
            var response = remove_product_from_session("", "", pro_cat, "all");
            
            if (response['tid'] !== typeof undefined && response['tid'] !== "" && response['tid'] === 0) {
                // add 0 value to input id = unique_id 
                // while inserting first product after removing all product.
                //we make 0, so it will skip validation of term id for first product
                jQuery("#unique_id").val(0);
            }
            
            if (response['product_count'] >= 2) {
                // when 2 or more than 2 product in compare tray enable compare button
                jQuery(".compare-button").removeClass("disabled");
            }
            else {
                // when product in compare tray is less than 2 , disable the compare button
                jQuery(".compare-button").addClass("disabled");
            }
            
            if (response['status'] === "1111") {
                //all product successfully remove from session
                //now emty all html from compare tray section
                jQuery("div .compare-item").each(function (index, element) {
                    var $this = jQuery(this);
                    //empty each product html in compare tray
                    var current_item_id = $this.attr('item_id');
                    if (typeof current_item_id !== typeof undefined && current_item_id !== false) {
                        var tmp = current_item_id.split("_");
                        var pro_pid = tmp[1];
                        var title = jQuery("div .description");
                        var img = jQuery("div .thumb_holder ");
                        var mrp = jQuery("div .product_mrp");
                        $this.find(img).html("");
                        $this.find(title).html("");
                        $this.find(mrp).html("");
                        $this.removeAttr('item_id');
                        $this.addClass("empty_item");
                        //now uncheck and remove active class in plp page
                        jQuery("#checkbox" + pro_pid).attr('checked', false);
                        jQuery("#checkbox" + pro_pid).parent().parent().removeClass('active');
                        //now remove disable class on pdp page anchor link on pdp page
                        //in case same product remove on it pdp page
                        var pdp_pro_pid = jQuery("#comp-button").attr('data-pid');
                        if (pdp_pro_pid == pro_pid) {
//                          console.log("remove disable class from pdp");
                            jQuery("#comp-button").removeClass("disabled");
                        }//else do nothing....
                    }
                    
                });
                
            }
            
        });
        //this function make ajax call and wait for response and return the response.
        function add_product_into_session(pro_sku, pro_cat, pro_id, n_id, page_name, plp_page_url) {
            
            var click_on_last_compare = jQuery("#last_compare_click").val();
            var exist_product_count = get_added_prduct_in_compare_tray();
            var pro_list = new Array();
            jQuery("div .compare-item").each(function (index, element) {
                var current_item_id = jQuery(this).attr('item_id');
                // get item_id from compare block
                if (typeof current_item_id !== typeof undefined && current_item_id !== false) {
//                        console.log(index+"=="+current_item_id);
                    var pid = current_item_id.split("_");
                    pro_list.push(pid[1]);
//                        console.log(index+"=="+pid[1]);
                }

            });
            var exist_pro_ls = ""+pro_list;
//            console.log("product list="+exist_pro_ls);
//            console.log("Seat Alocated = "+ exist_product_count);
            var res = "";
            jQuery.ajax({
                type: "POST",
                async: false,//we make false so this ajax call wait untill resoponse comes
                data: {'sku': pro_sku, 'tid': pro_cat, 'pro_id': pro_id, 'nid': n_id, 'plp_page_url': plp_page_url, 'seat_allocated':exist_product_count, 'exist_product': exist_pro_ls, 'last_comp_click':click_on_last_compare},
                dataType: 'json',
                cache: false, //for Chrome and IE8
                url: "/fetch_product_details",
                success: function (response) {
                    res = response;
                   // Drupal.attachBehaviors(context);
                },
                error: function (response) {
                    var $error_msg = "Oops! Something goes wrong " + response;
//                    show_error($error_msg);
                    window.location.reload(1); // incase of failure, reload current page
//                    jQuery(".compare-err-msg-holder").html("Oops! Something goes wrong " + response).show().delay(5000).fadeOut();
                    if(page_name === "plp"){
                        // add emty-item class and remove attr item-id also remove 
                        jQuery("div .req_item").addClass("empty_item");
                        jQuery("div .req_item").removeAttr("item_id");
                        jQuery("div .empty_item").removeClass("req_item");
                        jQuery("#checkbox" + response['pid']).attr('checked', false);
                        //uncheked the checkedbox while adding product to compare section 
                    }
                },
            });
            return res;
        }
        //this function make ajax call and wait for response and return the response.
        function remove_product_from_session(pro_id, n_id, pro_tid, product_type){
            var click_on_last_compare = jQuery("#last_compare_click").val();
            var res = "";
            jQuery.ajax({
                type: "POST",
                async: false,//we make false so this ajax call wait untill resoponse comes
                data: {'pro_id': pro_id, 'nid': n_id, 'tid': pro_tid, 'pro_type':product_type, 'last_comp_click':click_on_last_compare},
                dataType: 'json',
                cache: false, //for Chrome and IE8
                url: "/remove_product_from_compare_block",
                success: function (response) {
                    res = response;
                },
                error: function (response) {
                    var $error_msg = "Oops! Something goes wrong " + response;
//                    show_error($error_msg);
                    window.location.reload(1);// in case of failure , reload current page
//                    jQuery(".compare-err-msg-holder").html("Oops! Something goes wrong " + response).show().delay(5000).fadeOut();
                },
            });
            return res;
        }
        //display error function
        function show_error(msg){
            jQuery(".compare-err-msg-holder").html(msg).show().delay(5000).fadeOut();
        }
        // This function return total product in add to compare block
        function get_added_prduct_in_compare_tray(){
            var added_product_count = 0;
            jQuery("div.compare-item").each(function () {
                var current_item_id = jQuery(this).attr('item_id');
                if (!jQuery(this).hasClass("empty_item") && !jQuery(this).hasClass("req_item") && typeof current_item_id !== typeof undefined) {
                    // console.log(i);
                    added_product_count++;
                }
            });
            return added_product_count;
        }
        //Add to compare on pdp page
        jQuery('#comp-button').once().click(function () {
            jQuery("#block-bbd-compare-product-compare-products").show(); // show compare block on click on add to compare check box
            var $this = jQuery(this);
            var id = $this.attr('id');
            var pro_sku = $this.attr('data-sku');
            var pro_cat = $this.attr('data-unqueid');
            var pro_id = $this.attr('data-pid');
            var n_id = $this.attr('data-nid');
            var pro_key = n_id + "_" + pro_id;
            
            if (jQuery("#" + id).hasClass('disabled')) {
                var $error_msg = "Product already added in Compare tray";
                show_error($error_msg);
//                jQuery(".compare-err-msg-holder").html("Product already added in Compare tray").show().delay(5000).fadeOut();
                return false;
           }
           else{
                var i = 0;
                var exist_tray_cat = jQuery("#unique_id").val();
                if (exist_tray_cat !== typeof undefined && exist_tray_cat !== "" && exist_tray_cat != 0 ) {
                    //then compare whether added product belong to same tray category
                    if (exist_tray_cat != pro_cat && pro_cat !== "") {
//                        jQuery(".compare-err-msg-holder").html("Cant compare products from 2 different categories").show();
                        //first remove all html 
                        jQuery(".compare-items").empty();
                        //add empty html
                        var empty_html = '<div class="compare-item empty_item"><div class="thumb_holder"></div><div class="description"></div><div class="product_mrp"></div><span class="delete" title="Remove"></span></div>';
                        empty_html += '<div class="compare-item empty_item"><div class="thumb_holder"></div><div class="description"></div><div class="product_mrp"></div><span class="delete" title="Remove"></span></div>';
                        empty_html += '<div class="compare-item empty_item"><div class="thumb_holder"></div><div class="description"></div><div class="product_mrp"></div><span class="delete" title="Remove"></span></div>';
                        empty_html += '<div class="compare-item empty_item"><div class="thumb_holder"></div><div class="description"></div><div class="product_mrp"></div><span class="delete" title="Remove"></span></div>';
      
                        jQuery(".compare-items").append(empty_html);
//                        return false;
//                        console.log("Cant compare products from 2 different categories");
                    }
                }//else dont compare the added product with tray category
                jQuery("div .empty_item").each(function (index, element) {
                    i++;
                    var $this = jQuery(this);
                    var tmp = $this.attr('item_id');
                    if (tmp === undefined || tmp == '') {
                        // item id not exist so add the checked product using ajax in tray
                        $this.removeClass("empty_item");
                        $this.addClass("req_item");
                        $this.attr("item_id", pro_key);
                        // plp_page_url parameter value pass as empty string.
                        var response = add_product_into_session(pro_sku, pro_cat, pro_id, n_id, "pdp", "");
//                        console.log(response);
                        var current_item_id = jQuery("div .req_item").attr('item_id');
                        
                        if (typeof current_item_id !== typeof undefined && current_item_id !== false && current_item_id == response['nid'] + "_" + response['pid']) {
                            // add product details in compare block
                            var title = jQuery("div .description");
                            var img = jQuery("div .thumb_holder");
                            var mrp = jQuery("div .product_mrp");
                            var $this = jQuery("div .req_item");
                            $this.find(img).html(response['img_url']);
                            $this.find(title).html(response['title']);
                            $this.find(mrp).html(response['amount']);
                            $this.removeClass("req_item");// remove once added in compare tray
                            jQuery("#"+id).addClass("disabled");
                        }
                        else {
                            var $error_msg = "Something went wrong while adding product to tray";
                            show_error($error_msg);
                            window.location.reload(1);// in case error refresh current page
//                            jQuery(".compare-err-msg-holder").html("Something went wrong while adding product to tray").show().delay(5000).fadeOut();
//                                    console.log("Something went wrong while adding product to tray");
                        }
                        if(typeof response['page_refresh'] !== typeof undefined && response['page_refresh'] === "Yes"){
                            window.location.reload(1);// in case of total added product in add to compare block is different than exist product session
                        }
                        //now check if category switch, remove existing one 
                        if(typeof response['category_switch'] !== typeof undefined && response['category_switch'] === "Yes"){
                            //category is switch so remove previously added product
                            
//                            console.log("category switched...");
                            if (response['previous_compare_products'] !== typeof undefined && response['previous_compare_products'] !== "" ) {
//                                console.log("Show Previous compare block");
                                var site_url = window.location.origin;
                                var pre_pro_list = response['previous_compare_products'];
                                var pre_block_html = "<a target='_BLANK' href='/compare-product/previous/?ids="+pre_pro_list+"' class='pre-comp-url' onclick='setTimeout(function () {window.location.reload(1);}, 3000);'>Your Last Compare</a>";
                                var $this = jQuery("#previous-compare-products");
                                $this.html(pre_block_html);
                                $this.removeClass("hide-pre-tab");
                                $this.addClass("show-pre-tab");
                                jQuery("#block-bbd-compare-product-previous-compare-products").show();
                            }
                            else{
//                                console.log("Hide Previous compare block");
                                var $this = jQuery("#previous-compare-products");
                                $this.html("");
                                $this.removeClass("show-pre-tab");
                                $this.addClass("hide-pre-tab");
                                jQuery("#block-bbd-compare-product-previous-compare-products").hide();
                                
                            }
                        }
                        else{
//                            console.log("category Not ....switched...");
                        }
                        
                        //add or remove disabled class to compare button depend on product_count
                        if (response['product_count'] >= 2) {
                            // when 2 or more than 2 product in compare tray enable compare button
                            jQuery(".compare-button").removeClass("disabled");
                        }
                        else {
                            // when product in compare tray is less than 2 , disable the compare button
                            jQuery(".compare-button").addClass("disabled");
                        }
                        return false; // break the each loop once find empty compare tary item
                    }
                    else if (tmp !== undefined && tmp != '') {
//                        alert("Product allready exists in Compare Tray");
                        var $error_msg = "Product already exists in Compare Tray";
                        show_error($error_msg);
//                        jQuery(".compare-err-msg-holder").html("Product already exists in Compare Tray").show().delay(5000).fadeOut();
                    }

                });
                if (i == 0) {
                    var $error_msg = "You can compare maximum 4 products at a time.";
                    show_error($error_msg);
//                    jQuery(".compare-err-msg-holder").html("You can Compare atmost 4 Product at a time").show().delay(5000).fadeOut();
                    return false;// dont allow to check once tray is full
                }
            }
        });
    }
    
};
(function ($) {
    jQuery(document).ready(function ($) {
        //hide and show compare block  
        if(jQuery("#unique_id").hasClass("hide-tray")){
            //added product in cart and current page tid is not so, hide display compare block
            jQuery("#block-bbd-compare-product-compare-products").hide();
        }
        if(jQuery("#unique_id").hasClass("show-tray")){
            //added product in cart and current page tid is same so display compare block
            jQuery("#block-bbd-compare-product-compare-products").show();
        }
        // hide and show previous compare block
        if(jQuery("#previous-compare-products").hasClass("hide-pre-tab")){
            //added product in cart and current page tid is not so, hide display compare block
            jQuery("#block-bbd-compare-product-previous-compare-products").hide();
        }
        if(jQuery("#previous-compare-products").hasClass("show-pre-tab")){
            //added product in cart and current page tid is same so display compare block
            jQuery("#block-bbd-compare-product-previous-compare-products").show();
        }
        //click on compare button in compare tray
        jQuery('.compare-button').click(function () {
            if(jQuery(this).hasClass("disabled")){
                // do nothing , dont redirect to compare page
//                console.log("don't compare");
                return false;
            }
            else{
                // do compare , redirect to compare page
//                console.log("do compare");
                var pro_list = new Array();
                jQuery("div .compare-item").each(function (index, element) {
                    var current_item_id = jQuery(this).attr('item_id');
                    // get item_id from compare block
                    if (typeof current_item_id !== typeof undefined && current_item_id !== false) {
//                        console.log(index+"=="+current_item_id);
                        var pid = current_item_id.split("_");
                        pro_list.push(pid[1]);
//                        console.log(index+"=="+pid[1]);
                    }
                    
                });
//                console.log("pro list ="+pro_list);
                var go_to_url = "/compare-product/current/?ids="+pro_list;
//                console.log("URL="+go_to_url);
                window.open(go_to_url, '_blank');//open in new tab
            }
        });
    });
    //add scroll class to stick compare block
    jQuery(window).scroll(function () {
        
        var scroll = jQuery(window).scrollTop();
//        console.log(scroll);
        if (scroll >= 300) {
            jQuery("#block-bbd-compare-product-compare-products").addClass("scroll");
        }
        else {
            jQuery("#block-bbd-compare-product-compare-products").removeClass("scroll");
        }
    });
    //end of scroll class to stick compare block
})(jQuery);