(function ($) {
    jQuery(document).ready(function ($) {

        //slider on compare page
        jQuery('.bxslider').bxSlider({});

        //remove product from when click on clise image on compare page
        jQuery('.delete').click(function () {
            var pro_pid = jQuery(this).attr('data-pid');
            if (typeof pro_pid !== typeof undefined && pro_pid !== false) {

                jQuery.ajax({
                    type: "POST",
                    async: false, //we make false so this ajax call wait untill resoponse comes
                    data: {'pro_id': pro_pid},
                    dataType: 'json',
                    cache: false, //for Chrome and IE8
                    url: "/remove_product_from_compare_page",
                    success: function (response) {
                        var status = response['status'];
                        if (status == "1111") {
                            // when we get success
                            var pro_list = response['product_list'];
                            var go_to_url = "/compare-product/current/?ids=" + pro_list;
                            window.open(go_to_url, '_self');//open in same tab
                        }
                        else {
                            // when we get failure 
                            // do nothing
                        }
                    },
                    error: function (response) {
                        //do nothing
                    },
                });
            }
        });
        // click on add product on compare page
        jQuery('.add-product').click(function () {
//            console.log("click on add product");
            
            var pro_tid = jQuery(this).attr('data-tid');
            if (typeof pro_tid !== typeof undefined && pro_tid !== false) {

                jQuery.ajax({
                    type: "POST",
                    async: false, //we make false so this ajax call wait untill resoponse comes
                    data: {'pro_tid': pro_tid},
                    dataType: 'json',
                    cache: false, //for Chrome and IE8
                    url: "/get_plp_page_url",
                    success: function (response) {
                        
                        var plp_go_to_url = response['plp_page_url'];
                        window.open(plp_go_to_url, '_self');
                        
                    },
                    error: function (response) {
                        //do nothing
                    },
                });
            }
        });
        $(window).scroll(function () {
            var scrollTop = $(window).scrollTop();
            var windowHeight = $(window).height();
            var docHeight = $(document).height();
            var table_top = jQuery("#table_top");
            var add_to_cart = jQuery("#add_to_cart_foot");
            var footerHeight= $('#footer-links').height()+75;
            if (scrollTop >= 300) {   //to display the sticky header after scrolling
                table_top.removeClass("display_none");
                table_top.addClass("display_table");
            }
            else {  //hide the header when scrolled up again
                table_top.removeClass("display_table");
                table_top.addClass("display_none")
            }
            if (scrollTop + windowHeight > docHeight - footerHeight) {    //to remove sticky footer after reaching the page bottom
                add_to_cart.removeClass("addtocart_show_table");
                add_to_cart.addClass("addtocart_hide_table");
            }
           if (scrollTop + windowHeight < docHeight - footerHeight) {  //to show sticky footer after scrolling back up
                add_to_cart.removeClass("addtocart_hide_table");
                add_to_cart.addClass("addtocart_show_table");
            }
        });
    });
})(jQuery);
