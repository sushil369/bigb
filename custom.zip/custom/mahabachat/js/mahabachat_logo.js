jQuery(document).ready(function() {

    //jQuery('.mahabachat-img').removeAttr('style');
    jQuery('.mahabachat-img').addClass("mc-expire");
    jQuery('.time-left-section').css("display", "none");
    var domain_name = document.location.hostname;
    var cookieValue = jQuery.cookie("show_footer");

    if (cookieValue == 1) {
        // cookie value is set 1 so hide footer.
        jQuery("#block-mahabachat-mahabachat-footer").hide();
    }

    jQuery("#block-mahabachat-mahabachat-footer").addClass("sticky-mahabachat-footer");
    jQuery("#block-mahabachat-5-mahabachat-logo").addClass("sticky-5days-mahabachat-logo");
    jQuery(".mahabachat-close").click(function() {
        jQuery("#block-mahabachat-mahabachat-footer").hide();
        // set cookie value to 1 when close footer is clicked.
        jQuery.cookie("show_footer", 1, {path: "/", domain: domain_name});
    });
 if(jQuery( "#fgsf-footer" ).hasClass( "fgsf-footer" )){
    
    jQuery("#block-mahabachat-mahabachat-footer").removeClass("sticky-mahabachat-footer");
    jQuery("#block-mahabachat-mahabachat-footer").addClass("sticky-fgsf-footer");
   }
  
});


