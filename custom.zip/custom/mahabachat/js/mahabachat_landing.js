jQuery(document).ready(function ($) {
	$('body').addClass('holidaySale');
         if ($(window).width() < 736) {
             var src = '/sites/all/themes/bbd/images/phs_timerBg_landing.png';
             $('.mahabachat-img img').removeAttr('height width');
             $('.mahabachat-img img').attr('src',src);
         }
});