jQuery(document).ready(function () {
    
    if (jQuery(window).width() < 736) {
            var src = '/sites/all/themes/bbd/images/ss4dMobile-Icon.jpg';
            jQuery('.mahabachat-logo a img').attr('src',src);
            
            var src1 = '/sites/all/themes/bbd/images/ss4dMobile-footer.jpg';
            jQuery('.footer-mahabachat a img').removeAttr('height width');
            jQuery('.footer-mahabachat a img').attr('src',src1);
            
    }
         
    //auto close homepage mahabachat popup after 20 sec.
//    alert(Drupal.settings.mahabachat.display_flag);
    var state = Drupal.settings.mahabachat.display_flag;
//    console.log("132="+state);
    if(state !== typeof undefined){
        if (state) {
//        console.log("show popup");
        } else {
//        console.log("hide popup");
            jQuery("div #cboxWrapper").hide();
            // jQuery("div #cboxOverlay").css('visibility','hidden');
            jQuery("#cboxOverlay").remove();
        }
    }
    
    window.setInterval(closesplash, 20000); 
    function closesplash() {
        jQuery.colorbox.close();
        jQuery("div #cboxWrapper").removeClass("mahabachat-popup");
    }
    // add css class mahabachat-popup to colorboxwrapper 
    jQuery("div #cboxWrapper").addClass("mahabachat-popup");

});

Drupal.behaviors.mahabachat = {
    attach: function (context, settings) {
        jQuery('#cboxClose').click(function () {
            // remove css class mahabachat-popup to colorboxwrapper 
            
            jQuery("div #cboxWrapper").removeClass("mahabachat-popup");
        });
           jQuery('.cart-clicked-item').click(function (e) {
            jQuery("#modalContent").addClass("add_to_cart_notification");
        });
//        alert(Drupal.settings.mahabachat.display_flag);
    }
};