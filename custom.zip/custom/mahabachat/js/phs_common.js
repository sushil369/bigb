
jQuery(document).ready(function ($) {
         if ($(window).width() < 736) {
             var src0 = '/sites/all/themes/bbd/images/phs_timerBg_landing1.jpg';
             $('.mahabachat-img img').removeAttr('height width');
             $('.mahabachat-img img').attr('src',src0);
             
            var src1 = '/sites/all/themes/bbd/images/ss4dMobile-Icon.jpg';
            $('.mahabachat-logo a img').attr('src',src1);
            
            var src2 = '/sites/all/themes/bbd/images/ss4dMobile-footer.jpg';
            $('.footer-mahabachat a img').removeAttr('height width');
            $('.footer-mahabachat a img').attr('src',src2);
         }
});

