<?php

module_load_include('inc', 'bbd_master_slave', 'includes/bbd_master_slave_constant');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function get_master_slave_roles($roles) {
  $roleDetail = NULL;
  if (array_search(MASTER_ROLE_NAME, $roles)) {
    $roleDetail['role_name'] = MASTER_ROLE_NAME;
    $roleDetail['role_id'] = array_search($roleDetail['role_name'], $roles);
  }
  if (array_search(SLAVE_ROLE_NAME, $roles)) {
    $roleDetail['role_name'] = SLAVE_ROLE_NAME;
    $roleDetail['role_id'] = array_search($roleDetail['role_name'], $roles);
  }
  if (array_search(CHILD_ROLE_NAME, $roles)) {
    $roleDetail['role_name'] = CHILD_ROLE_NAME;
    $roleDetail['role_id'] = array_search($roleDetail['role_name'], roles);
  }
  return $roleDetail;
}

function get_slave_user_id($orderID) {
  $query = db_select('field_data_field_master_slave_franchise_id', 'msf');
  $query->fields('msf', array('field_master_slave_franchise_id_uid'));
  $query->condition('msf.entity_id', $orderID);
  $res = $query->execute()->fetchField();
  return $res;
}

function get_parent_code_from_slave($uid) {
  $query = db_select('field_data_field_select_master', 'b');
  $query->join('profile', 'p', 'p.pid = b.entity_id');
  $query->fields('b', array('field_select_master_uid'));
  $query->fields('p', array('uid'));
  $query->condition('p.uid', $uid);
  $res = $query->execute()->fetchAll();
  return $res;
}

function assigned_masterCount($master_uid, $service = NULL, $rid = NULL) {
  $query = db_select("field_revision_field_select_master ", "sm");
  $query->fields("sm", array("field_select_master_uid"));
  $query->fields("p", array("uid"));
  $query->leftjoin('profile', 'p', 'p.pid=sm.entity_id');
  if ($rid) {
    $query->leftjoin('users_roles', 'ur', 'ur.uid=p.uid');
    $query->condition('ur.rid', $rid, '=');
  }
  $query->condition('sm.field_select_master_uid', $master_uid);
  if ($service) {
    $output = $query->execute()->fetchAll();
  }
  else {
    $output = $query->execute()->rowCount();
  }
  return $output;
}

function get_role_ids() {
  $roles = user_roles();
  $output['franchisee_rid'] = array_search(FRANCHISEE_ROLE_NAME, $roles);
  $output['master_rid'] = array_search(MASTER_ROLE_NAME, $roles);
  $output['slave_rid'] = array_search(SLAVE_ROLE_NAME, $roles);
  $output['child_rid'] = array_search(CHILD_ROLE_NAME, $roles);
  $output['dpt_rid'] = array_search(DPT_ROLE_NAME, $roles);
  return $output;
}

function get_masterslave_franchisee_commission($franchisee_id, $slave_id = NULL, $date = REQUEST_TIME) {
  $query = db_select('user_wallet', 'uw');
  $query->addExpression('SUM(uw.commission_amount)', 'uw.commission_amount');
  if ($slave_id) {
    $query->leftjoin('field_data_field_master_slave_franchise_id', 'sfc', 'sfc.entity_id = uw.order_id ');
  }
  $query->condition('uw.uid', $franchisee_id, '=');
  if ($slave_id) {
    $query->condition('sfc.field_master_slave_franchise_id_uid', $slave_id, '=');
  }
  $query->condition('uw.date', $date, '<=');
  $result = $query->execute()->fetchField();
  if ($result) {
    $result = number_format($result / 100, 2);
  }
  else {
    $result = 0;
  }
  return $result;
}

function get_masterslave_franchisee_revenue($franchisee_id, $slave_id = NULL, $date = REQUEST_TIME) {
  $query = db_select('field_data_commerce_order_total', 'ot');
  $query->addExpression('SUM(ot.commerce_order_total_amount)', 'commerce_order_total_amount');
  $query->leftjoin('user_wallet', 'uw', 'uw.order_id = ot.entity_id');
  $query->leftjoin('field_data_field_franchisee_uid', 'ffu', 'ffu.entity_id = ot.entity_id ');
  if ($slave_id) {
    $query->leftjoin('field_data_field_master_slave_franchise_id', 'sfc', 'sfc.entity_id = ffu.entity_id ');
    $query->condition('sfc.field_master_slave_franchise_id_uid', $slave_id, '=');
  }
  $query->condition('ffu.field_franchisee_uid_uid', $franchisee_id, '=');
  $query->condition('uw.date', $date, '<=');
  $result = $query->execute()->fetchField();

  if ($result) {
    $result = number_format($result / 100, 2);
  }
  else {
    $result = 0;
  }

  return $result;
}

/**
 * 
 * @param type $franchisee_code
 * Returns list of phone commerce orders from Frnachisee code
 */
function android_service_get_slave_processing_orders_from_franchisee_code($franchisee_code) {
  $status = array('slave_processing');
  $query = db_select('field_data_field_franchisee_uid', 'ffu');
  $query->join('commerce_order', 'co', 'co.order_id = ffu.entity_id');
  $query->join('field_data_field_franchisee_code', 'fc', 'fc.entity_id = ffu.field_franchisee_uid_uid');
  $query->addField('ffu', 'entity_id', 'order_id');
  $query->condition('fc.field_franchisee_code_value', $franchisee_code);
  $query->condition('co.status', $status, 'IN');
  $orders = $query->execute()->fetchAll();
  return $orders;
}

function get_city_id_from_pincode($pincode) {
  $query = db_select('taxonomy_term_data', 't');
  $query->join('taxonomy_term_hierarchy', 'th', 't.tid = th.tid');
  $query->fields('th', array('parent'));
  $query->condition('t.name', $pincode);
  $res = $query->execute()->fetchField();
  return $res;
}

function gettimestamp_last_transact($uid) {
  $res = NULL;
  $query = db_select('field_data_field_master_slave_franchise_id', 'ms');
  $query->join('commerce_order', 'co', 'co.order_id = ms.entity_id');
  $query->fields('co', array('changed'));
  $query->range(0, 1);
  $query->condition('ms.field_master_slave_franchise_id_uid', $uid);
  $res = $query->orderBy('co.changed', 'DESC')->execute()->fetchField();
  if ($res) {
    $res = date("Y-m-d G:i:s", $res);
    $time_ago = strtotime($res);
    $timeVal = timeAgo($time_ago);
    return $timeVal;
  }
  else {
    return $res;
  }
}

function timeAgo($time_ago) {
  $cur_time = time();
  $time_elapsed = $cur_time - $time_ago;
  $seconds = $time_elapsed;
  $minutes = round($time_elapsed / 60);
  $hours = round($time_elapsed / 3600);
  $days = round($time_elapsed / 86400);
  $weeks = round($time_elapsed / 604800);
  $months = round($time_elapsed / 2600640);
  $years = round($time_elapsed / 31207680);
// Seconds
  if ($seconds <= 60) {
    $time = "$seconds seconds ago";
  }
//Minutes
  else if ($minutes <= 60) {
    if ($minutes == 1) {
      $time = "one minute ago";
    }
    else {
      $time = "$minutes minutes ago";
    }
  }
//Hours
  else if ($hours <= 24) {
    if ($hours == 1) {
      $time = "an hour ago";
    }
    else {
      $time = "$hours hours ago";
    }
  }
//Days
  else if ($days <= 7) {
    if ($days == 1) {
      $time = "yesterday";
    }
    else {
      $time = "$days days ago";
    }
  }
//Weeks
  else if ($weeks <= 4.3) {
    if ($weeks == 1) {
      $time = "a week ago";
    }
    else {
      $time = "$weeks weeks ago";
    }
  }
//Months
  else if ($months <= 12) {
    if ($months == 1) {
      $time = "a month ago";
    }
    else {
      $time = "$months months ago";
    }
  }
//Years
  else {
    if ($years == 1) {
      $time = "one year ago";
    }
    else {
      $time = "$years years ago";
    }
  }
  return $time;
}

/**
 * 
 * @param type $order_ids
 */
function master_slave_check_wallet_balance_sufficient($order_ids, $franchisee_uid) {
  $no_of_ids = count($order_ids);
  $query = db_select('field_data_commerce_order_total', 'ct');
  $query->join('commerce_order', 'co', 'co.order_id = ct.entity_id');
  $query->addExpression('SUM(commerce_order_total_amount)', 'total');
  $query->addExpression('COUNT(entity_id)', 'total_ids');
  $query->condition('ct.entity_type', 'commerce_order');
  $query->condition('ct.entity_id', $order_ids, 'IN');
  $query->condition('co.status', 'slave_processing');
  $res = $query->execute()->fetchAll();
  $wallet_balance = user_wallet_get_balance($franchisee_uid);

  if ($no_of_ids != $res[0]->total_ids) {
    return 'Invalid Order Id';
  }
  elseif ($wallet_balance < $res[0]->total) {
    return 'Insufficient Wallet balance';
  }
  else {
    return 'TRUE';
  }
}
