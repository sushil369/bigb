(function ($) {
    $(document).ready(function () {
        $(".count-4").parent('.content').parent('#block-views-recommended-products-block-1').css('width:720px');
        $(".count-6").parent('.content').parent('#block-views-recommended-products-block-1').css('width:1100px');
        jQuery('#edit-submit').click(function () {
            alert('hi');
        });
    });
});