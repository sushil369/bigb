
<div class="thank-u-pg">
    <div class="top-tabs-outer"><?php print($img_url); ?></div>
    <p><?php print($h1_msg); ?></p><br/>
    <p><b>Thank You For Your Order</b></p><br/>
    <p><?php print($p1_msg); ?></p>
    <p class="thnk-bold"><?php print($p2_msg); ?></p>
    <p><?php print($p3_msg); ?></p>
    <div class="track-order-btn"><?php print($track_order); ?></div>      
    <p><?php print($p4_msg); ?></p>
    <div class = "line-item-table-thank-you-pg">
        <?php print($line_item_table); ?>
    </div>
</div>


