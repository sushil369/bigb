//on offer image hover show offer text on plp and pdp page.

(function($) {
    Drupal.behaviors.bbd_category = {
        attach: function(context) {
            jQuery(window).load(function() {
                //  START : MOBILE :  get value of 'sortby' from url and set sortby dropdown option accordingly
                function GetURLParameter(sParam)
                {
                    var sPageURL = window.location.search.substring(1);
                    var sURLVariables = sPageURL.split('&');
                    for (var i = 0; i < sURLVariables.length; i++)
                    {
                        var sParameterName = sURLVariables[i].split('=');
                        if (sParameterName[0] == sParam)
                        {
                            return sParameterName[1];
                        }
                    }
                }

                var sortbyValue = GetURLParameter('sortby');

                if (sortbyValue != 'undefined') {
                    var selectValue = $("#edit-sort-by option[value='" + sortbyValue + "']").prop('selected', true);
                    var textValue = jQuery("#edit-sort-by option:selected").text();
                    console.log(textValue);
                    textValue = (textValue == 'Sort') ? 'None' : textValue;
                    $('.toggle.sorttype .alterText').html('Sort by <b>' + textValue + '</b>');
                }
                //  END
            });

            jQuery('.sort-by-a').click(function() {

                var key = $(this).attr('key');
                var url = window.location.href;
                var url = window.location.href;

                if (url.indexOf('?') > -1) {

                    if (url.indexOf('sortby=') > -1) {
                        var regEx = /([?&]sortby)=([^#&]*)/g;
                        url = url.replace(regEx, '$1=' + key);
                    } else {

                        url += '&sortby=' + key;

                    }

                } else {

                    url += '?sortby=' + key;

                }

                window.location.href = url;
            });

            jQuery('#edit-sort-by').change(function() {
                var url = window.location.href;
                var value = jQuery("#edit-sort-by option:selected").val();
                if (url.indexOf('?') > -1) {

                    if (url.indexOf('sortby=') > -1) {
                        var regEx = /([?&]sortby)=([^#&]*)/g;
                        url = url.replace(regEx, '$1=' + value);
                    } else {

                        url += '&sortby=' + value;

                    }

                } else {

                    url += '?sortby=' + value;

                }

                window.location.href = url;
            });


            jQuery('.promotion-l').mouseover(function() {
                jQuery(this).next('div.promotion-text').show();
                //jQuery('div.promotion-text').show();
                //jQuery(this).parent().next('div.promotion-text').show();

            });

            jQuery('.promotion-l').mouseout(function() {
                jQuery(this).next('div.promotion-text').hide();
                //jQuery('div.promotion-text').hide();
                // jQuery(this).parent().next('div.promotion-text').hide();

            });

        }
    };
})(jQuery);


