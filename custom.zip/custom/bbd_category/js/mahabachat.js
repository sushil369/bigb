/**
 * @file
 * The theme system, which controls the output of Drupal.
 *
 * The theme system allows for nearly all output of the Drupal system to be
 * customized by user themes.
 */

(function($) {
    jQuery(document).ready(function($) {
        $("#mahabachat_tab").tabs();
        
        $('li.fashion-link').click(function() {
            window.location.reload();
        });
    });


})(jQuery);