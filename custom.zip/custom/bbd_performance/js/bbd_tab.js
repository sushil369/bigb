/**
 * @file
 * The theme system, which controls the output of Drupal.
 *
 * The theme system allows for nearly all output of the Drupal system to be
 * customized by user themes.
 */

(function ($) {
    jQuery(document).ready(function ($) {
        $("#Tabs1").tabs();
        $("#Tabs2").tabs();
        $("#Tabs3").tabs();

//        $('.promotion-l img').click(function () {
//            $(this).parent().next('div.promotion-text').show();
//
//        });
//
//    });
//    jQuery(document).mouseup(function (e)
//    {
//        var container = $(".promotion-l img");
//
//        if (!container.is(e.target) // if the target of the click isn't the container...
//                && container.has(e.target).length === 0) // ... nor a descendant of the container
//        {
//            $('.promotion-l').next('div.promotion-text').hide();
//        }

        jQuery.noConflict();

        jQuery('.promotion-l img').mouseover(function () {
            jQuery(this).parent().next('div.promotion-text').show();
            //jQuery('div.promotion-text').show();
            //jQuery(this).parent().next('div.promotion-text').show();

        });

        jQuery('.promotion-l img').mouseout(function () {
            jQuery(this).parent().next('div.promotion-text').hide();
            //jQuery('div.promotion-text').hide();
            // jQuery(this).parent().next('div.promotion-text').hide();

        });


    });

})(jQuery);