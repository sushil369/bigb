/**
 * @file
 * The theme system, which controls the output of Drupal.
 *
 * The theme system allows for nearly all output of the Drupal system to be
 * customized by user themes.
 */

(function ($) {

    Drupal.behaviors.bbd_performance = {
        attach: function (context) {
            $(document).on("click", '.add-wish-list', function (e) {

              e.preventDefault();
                 var document_width = $(document).width() + "px";
                 var document_height = $(document).height() + "px";
                var uid = $(this).attr('uid');
                var product_id = $(this).attr('product_id');
                var nid = $(this).attr('nid');
                var token = $(this).attr('token');
               
               var base_url = window.location.origin;
               
                var url = base_url+'/wishlist-actions/ajax/add/' + uid + '/' + product_id + '/' + nid + '?token=' + token;
                var wishlist = base_url+'/user/wishlist';
                var $this = $(this);
                $.ajax({
                    type: "GET",
                    cache: false, //for Chrome and IE8
                    url: url,
                    success: function (response) {
                        
                         $("a.active").removeClass("add-wish-list");
                        $this.addClass("added-to-wishlist");
//                        $this.text('Added-to-wishlist');
                        $this.parent().parent().removeClass("add-to-wishlist");
                        $this.parent().parent().addClass("added-to-wishlist");
                       
                        var res = "<div class = 'wish-msg'>Successfully Added to Wishlist.<a href ="+wishlist+" >Click Here to see your Wishlist</div>";
                        jQuery.colorbox({html: res , className: 'wishlist-pop-msg'}); //$("#colorbox")$.colorbox
     
                    },
                });

//                $.ajax({
//                    type: "GET",
//                    cache: false, //for Chrome and IE8
//                    url: base_url+"/customer-cart/remove_line_item?item=" + $(this).attr('sku_item') + "&sku=" + $(this).attr('sku'),
//                    success: function (responce) {
//
//                    },
//                  
//
//                });
            });            
            var image_outer = $(".front .views-field-field-product-images a");
            image_outer.mouseenter(function (e) {
                var $this = $(this);
                var nid = $this.attr("data");
                var tag = $this.attr("tag");

                loadImageSlider($this, nid, tag);
            });


            $('.front .views-field-field-product-images').mouseleave(function (e) {
                var $this = $(this);
                var anchor = $this.find('a');
                anchor.cycle("stop").cycle({
                    startingSlide: 0,
                    fx: "fade"
                });
                anchor.cycle("destroy");
                // anchor.find('img').animate({'zoom': 1}, 400, "swing");
                anchor.find('img:first').css({"opacity": "1", "display": "block"});
                anchor.removeClass("zoom-img-tag");
                anchor.next().hide();
            });

            function loadImageSlider($this, nid, tag) {
                if ($this.children("img").length > 1) {
                    $this.find('img:first').hide();
                    if ($this.children("img").length > 1 && $this.children("img").length < 3) {
                        $this.find('img').eq(1).css({"opacity": "1", "display": "block"});
                    }
                    if ($this.children("img").length > 2) {
                        $this.cycle({
                            continuous: 0,
                            delay: 0,
                            speed: 500,
                            autostop: true,
                            timeout: 1000,
                            allowPagerClickBubble: true,
                            slideExpr: '.tag-slide',
                        });
                    }
                   
                    // $this.find('img').slice(1).animate({'zoom': 1.2}, 400, "swing");
                    $this.next().show();
                    $this.addClass("zoom-img-tag");
                }
                else {
                    $.ajax({
                        type: "POST",
                        url: '/get-image-probes-via-ajax',
                        data: {nid: nid, tag: tag},
                        success: function (data) {
                            $this.append(data);

                            if ($this.is(":hover")) {
                                $this.find('img:first').hide();
                                if ($this.children("img").length > 1 && $this.children("img").length < 3) {
                                    $this.find('img').eq(1).css({"opacity": "1", "display": "block"});
                                }
                                if ($this.children("img").length > 2) {
                                    $this.cycle({
                                        continuous: 0,
                                        delay: 0,
                                        speed: 500,
                                        timeout: 1000,
                                        autostop: true,
                                        allowPagerClickBubble: true,
                                        slideExpr: '.tag-slide',
                                    });
                                    // $this.find('img').slice(1).animate({'zoom': 1.2}, 400, "swing");
                                   
                                    $this.next().show();
                                    $this.addClass("zoom-img-tag");
                                }
                                else {
                                    // $this.find('img').animate({'zoom': 1.2}, 400, "swing");
                                    
                                    $this.next().show();
                                    $this.addClass("zoom-img-tag");
                                }
                            }
                            else {
                                // $this.find('img').animate({'zoom': 1}, 400);
                                
                            }
                        }
                    });
                }
            }

            function onAfter(curr, next, opts) {
                var index = opts.currSlide;
                $(opts.prev)[index == 0 ? 'hide' : 'show']();
                $(opts.next)[index == opts.slideCount - 1 ? 'hide' : 'show']();
            }


            for (var i = 1; i < 6; i++) {
                if ($("#Tabs1 #tabs-" + i).length > 0) {
                    $("#Tabs1 #tabs-" + i).cycle({
                        next: ".cycle-next-0-" + i,
                        prev: ".cycle-previous-0-" + i,
                        timeout: 0,
                        fx: 'scrollHorz',
                        slideExpr: 'div.slider-outer',
                        nowrap: 1,
                        after: onAfter,
                    });
                }
            }


            for (var i = 1; i < 6; i++) {
                if ($("#Tabs2 #tabs-" + i).length > 0) {
                    $("#Tabs2 #tabs-" + i).cycle({
                        next: ".cycle-next-1-" + i,
                        prev: ".cycle-previous-1-" + i,
                        timeout: 0,
                        fx: 'scrollHorz',
                        slideExpr: 'div.slider-outer',
                        nowrap: 1,
                        after: onAfter,
                    });
                }
            }



            for (var i = 1; i < 6; i++) {
                if ($("#Tabs3 #tabs-" + i).length > 0) {
                    $("#Tabs3 #tabs-" + i).cycle({
                        next: ".cycle-next-2-" + i,
                        prev: ".cycle-previous-2-" + i,
                        timeout: 0,
                        fx: 'scrollHorz',
                        slideExpr: 'div.slider-outer',
                        nowrap: 1,
                        after: onAfter,
                    });
                }
            }




//            if ($(".na-bs-slider").length > 0) {
//                $(".na-bs-slider").cycle({
//                    next: '.cycle-next',
//                    prev: '.cycle-previous',
//                    timeout: 0,
//                });
//            }

            if ($(".na-bs-slider-4").length > 0) {
                $(".na-bs-slider-4").cycle({
                    next: '.cycle-next-4',
                    prev: '.cycle-previous-4',
                    timeout: 0,
                });
            }

            if ($(".rp-slider").length > 0) {
                $(".rp-slider").cycle({
                    next: '.cycle-next-r',
                    prev: '.cycle-previous-r',
                    timeout: 0,
                });
            }
            if ($(".rv-slider").length > 0) {
                $(".rv-slider").cycle({
                    next: '.cycle-next-v',
                    prev: '.cycle-previous-v',
                    timeout: 0,
                });
            }
            if ($(".sopdp-slider").length > 0) {
                $(".sopdp-slider").cycle({
                    next: '.cycle-next-sopdp',
                    prev: '.cycle-previous-sopdp',
                    timeout: 0,
                });
            }
            if ($(".naplp-slider").length > 0) {
                $(".naplp-slider").cycle({
                    next: '.cycle-next-n',
                    prev: '.cycle-previous-n',
                    timeout: 0,
                });
            }
            if ($(".rpplp-slider").length > 0) {
                $(".rpplp-slider").cycle({
                    next: '.cycle-next-rp',
                    prev: '.cycle-previous-rp',
                    timeout: 0,
                });
            }
            if ($(".ymalpdp-slider").length > 0) {
                $(".ymalpdp-slider").cycle({
                    next: '.cycle-next-ymalpdp',
                    prev: '.cycle-previous-ymalpdp',
                    timeout: 0,
                });
            }
            if ($(".ymalpdp-slider-mobile").length > 0) {
                $(".ymalpdp-slider-mobile").slick({
                    infinite: true,
                    speed: 500,
                    arrows: true,
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    draggable: false
                });
            }

            if ($('#block-bbd-performance-recommended-products').length > 0) {
                if ($("#block-bbd-performance-recommended-products .rp-slider").attr('data') == 6) {
                    $('#block-bbd-performance-recently-viewed').addClass('rv-empty');
                    $('#block-bbd-performance-recommended-products').addClass('rv-c');
                }
                else {
                    $('#block-bbd-performance-recommended-products').addClass('rv-o');
                    $('#block-bbd-performance-recently-viewed').addClass('rv-not-empty');
                }
            }
            $("input[name='shipping_postal_code']").blur(function (e) {
                e.preventDefault();
                var pincode = $(this).attr('value');
                $.ajax({
                    type: "POST",
                    url: "/get/city/state",
                    data: "pincode=" + pincode,
                    success: function (response) {
                        
                        if (!response['state'] || !response['city']) {
                            $("input[name='shipping_administrative_area']").val('');
                            $("input[name='shipping_locality']").val('');
                            $("input[name='shipping_administrative_area']").removeAttr('readonly');
                            $("input[name='shipping_locality']").removeAttr('readonly');
                        }
                        else {
                            $("input[name='shipping_administrative_area']").val(response['state']);
                            $("input[name='shipping_locality']").val(response['city']);
                            $("input[name='shipping_administrative_area']").attr('readonly', 'readonly');
                            $("input[name='shipping_locality']").attr('readonly', 'readonly');
                        }
                    }
                });
            });
            $("input[name='billing_postal_code']").blur(function (e) {
                e.preventDefault();
                var pincode = $(this).attr('value');
                $.ajax({
                    type: "POST",
                    url: "/get/city/state",
                    data: "pincode=" + pincode,
                    success: function (response) {
                        if (!response['state'] || !response['city']) {
                            $("input[name='billing_administrative_area']").val('');
                            $("input[name='billing_locality']").val('');
                            $("input[name='billing_administrative_area']").removeAttr('readonly');
                            $("input[name='billing_locality']").removeAttr('readonly');
                        }
                        else {
                            $("input[name='billing_administrative_area']").val(response['state']);
                            $("input[name='billing_locality']").val(response['city']);
                            $("input[name='billing_administrative_area']").attr('readonly', 'readonly');
                            $("input[name='billing_locality']").attr('readonly', 'readonly');
                        }
                    }
                });
            });
        }
    };
})(jQuery);
