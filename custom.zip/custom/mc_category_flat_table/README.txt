-----------------------------------------------------------------------------------------------------------------------------------------------------
Introduction
-----------------------------------------------------------------------------------------------------------------------------------------------------
Module name		: 	mc_category_flat_table
Info			:	Generates a flat table for mc categories on insert/delete/update of taxonomy term.
				Contains mapping of leaf_tid vs root_tid. 
Url to sync manually	:	[site-url]/sync/mc
-----------------------------------------------------------------------------------------------------------------------------------------------------
Features
-----------------------------------------------------------------------------------------------------------------------------------------------------
Sync Manually 		: 	Sync entire mc category flat table.
Function/Hook name	: 	sync_mc_category()
Procedure		: 	Enter the url : [site-url]/sync/mc
Working			:	step 1 - Determine all root level categories. 
				step 2 - Determine all children categories for each root level category (leaf level + nonleaf level).
				step 3 - Determine all non leaf level categories for each root level category (nonleaf level).
				step 4 - Determine all leaf level categories by getting difference between step 2 and step 3 results.
				step 5 - Determine all leaf level categories from mc_category_flat_table(if any record exist).
				step 6 - Determine the obsolete(unwanted) records in the flat table by array_diff_key(step 5 result, step 6 result)
				step 7 - Bulk delete all obsolete records from the mc_category_flat_table.
				step 8 - Insert all the records into mc_category_flat_table.

Sync on term insert	:	Whenever a new term is added in any category level, mc_category_flat_table is updated automatically.
Function/Hook name	:	mc_category_flat_table_taxonomy_term_insert($term)
Procedure		:	Add a new taxonomy term in mc_category vocabulary.
Working			:	step 1 - Determine all  children categories of the newly added term (leaf level + nonleaf level).
				step 2 - Determine immediate parent's tid for the newly added term.
				step 3 - Determine root's tid for the newly added term.
				step 4 - Check if parent(from step2) already exists in mc_category_flat_table
				step 5 - If parent record exists, delete it and add a new record for newly added term. 
				         Else if parent record doesn't exist, insert a new record in flat table for newly added term.

Sync on term delete	:	Whenever a term is deleted, mc_category_flat_table is updated automatically.
Function/Hook name	:	mc_category_flat_table_taxonomy_term_delete($term)
Procedure		:	Add a any taxonomy term from mc_category vocabulary.
Working			:	step 1 - If its record exist in mc_category_flat_table, delete it.
				step 2 - sync entire table so as to make sure the newly created leaf level categories in the process are synced.

Sync on update		:	Whenever a term is updated(its parent is changed), mc_category_flat_table is updated automatically.  
Function/Hook name	:	mc_category_flat_table_taxonomy_term_update($term)	
Procedure		:	Update any taxonomy term from mc_category vocabulary.
Working			:	step 1 - sync entire table so as to make sure the newly created leaf level categories in the process are synced.
Exceptions		:	If a taxonomy term hierarchy is changed by drag n drop on the [taxonomy-overview-terms] form, 					hook_taxonomy_term_update doesn't work. So making use of hook_form_submit[mc_category_flat_table_form_submit].
------------------------------------------------------------------------------------------------------------------------------------------------------
Helper Functions List
------------------------------------------------------------------------------------------------------------------------------------------------------
get_all_root_categories($vid);
get_all_children_categories($roots, $vid);
get_all_non_leaf_categories($vid);
leaf_tids_from_mc_category_root_tid($cat_tid);
get_all_leaf_categories($children_categories, $non_leaf_categories);
get_immediate_parent_category($tid);
get_row_from_mc_category_flat_table($tid);
insert_to_mc_categories_flat_table($leaf_categories);
delete_from_mc_category_flat_table($tid);
bulk_delete_from_mc_category_flat_table($tid_arr);
get_all_leaf_tids_from_mc_category_flat_table();
truncate_table($table);
------------------------------------------------------------------------------------------------------------------------------------------------------
Hooks List
------------------------------------------------------------------------------------------------------------------------------------------------------
mc_category_flat_table_menu();
mc_category_flat_table_taxonomy_term_insert($term);
mc_category_flat_table_taxonomy_term_delete($term);
mc_category_flat_table_taxonomy_term_update($term);
mc_category_flat_table_form_alter(&$form,$form_state, $form_id);
mc_category_flat_table_form_submit($form, &$form_state);




