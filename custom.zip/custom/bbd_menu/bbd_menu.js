jQuery(document).ready(function ($) {
    //$.noConflict();
    // $('#block-bbd-menu-block-menu-responsive').appendTo('.region-search-box');
    $('.second_level_parent_div').hide();
    $('.first_level_parent_div, .second_level_parent_div').mouseover(function () {
        if ($(this).hasClass("first_level_parent_div")) {
            var child_class_to_show = this.id;
            $('.' + child_class_to_show).show();
        } else {
            var clas_name = $(this).attr("class");
            var clas_to_show = clas_name.split(' ');
            $('.' + clas_to_show[0]).show();
            $('#' + clas_to_show).addClass('hightlight');
        }
    }).mouseout(function () {
        if ($(this).hasClass("first_level_parent_div")) {
            var child_class_to_show = this.id;
            $('.' + child_class_to_show).hide();
        } else {
            var clas_name = $(this).attr("class");
            var clas_to_show = clas_name.split(' ');
            $('.' + clas_to_show[0]).hide();
            $('#' + clas_to_show).removeClass('hightlight');
        }
    });
    
    $('#block-bbd-menu-block-menu-responsive').hide();
});
