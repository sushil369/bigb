
<!--new track order page-->
<div class="track-order-pg">
    <div><?php print $order['order_detail']; ?></div>
    <?php print $order['line_html']; ?>
    <div class="final-Shipvalue"><span class="tv-label">Shipping Charge:</span><span class="tv-amt">Rs.<?php print $order['ship_total']; ?></span></div>
    <div class="final-totalvalue"><span class="tv-label">Total Value:</span><span class="tv-amt">Rs.<?php print $order['order_total']; ?></span></div>
</div>
