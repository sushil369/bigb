
<!--new track order page-->
<div class="track-order-pg">
    <div><?php print $order['order_detail']; ?></div>
    <table width="100%" class="trck-o">
        <tr class="row-header">
            <th scope="col" class="p-spacer">&nbsp;</th>
            <th scope="col" class="p-detail-head">Product Details</th>
            <th scope="col" class="p-detail-8-head"><table width="100%">
            <tr>
              <!--<th scope="col" class="select-radio">&nbsp;</th>-->
                <th scope="col" class="p-qty">Qty</th>
                <th scope="col" class="p-approval">Approval</th>
                <th scope="col" class="p-processing">Processing</th>
                <th scope="col" class="p-shipping">Shipping</th>
                <th scope="col" class="p-delivery">Delivery</th>
                <th scope="col" class="p-exception">Exception</th>
                <th scope="col" class="p-subtotal">Subtotal</th>
            </tr>
        </table></th>
        <th scope="col" class="p-spacer">&nbsp;</th>
        </tr>
        <?php print $order['line_html']; ?>
        <tr class="row-data-cta">
            <td class="p-d-spacer">&nbsp;</td>
            <td colspan="2" class="bottom-cta-tv">
                <div class="final-Shipvalue"><span class="tv-label">Shipping Charge:</span><span class="tv-amt">Rs.<?php print $order['ship_total']; ?></span></div>
                <div class="final-totalvalue"><span class="tv-label">Total Value:</span><span class="tv-amt">Rs.<?php print $order['order_total']; ?></span></div>
            </td>
            <td class="p-d-spacer">&nbsp;</td>
        </tr>
    </table>
    <div class="track-order-back"><?php print $order['order_back']; ?></div>

</div>
