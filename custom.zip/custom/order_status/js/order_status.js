(function ($) {

    Drupal.behaviors.order_status = {
        attach: function (context) {
//        $('.p-d-select-radio input').click(function(){
//            $('.p-d-select-radio input').removeClass('active');
//            $(this).addClass('active');
//            //var data = $(this).parents('.line-item-id').attr('data');
//            $('.cta-row-hidden').hide();
//            $(this).parents('.p-detail-8-td').find('.cta-row-hidden').show();
//            $('.p-d-select-radio input').each(function(){
//                if(!$(this).hasClass('active')){
//                   $(this).removeAttr('checked'); 
//                }       
//            });
//        });

//        $('.bottm-cta a').click(function(e){
//            e.preventDefault();
//            var data = $(this).parent().attr('data');
//            if(!isNaN(data)){
//              var href = $(this).attr('href'); 
//              window.location = window.location.origin + href + '&id=' + data;    
//            }else{
//              alert("Please select a product");
//            }
//            
//        });

            $('#edit-upload-image-upload:not(.processed-file)').change(function () {
                if (!$(this).hasClass('processed-file')) {
                    $(this).before('<div class="file-added"></div>');
                    $(this).addClass('processed-file');
                }
            });

            $('.print-button').click(function () {
                var printContents = document.getElementById('order-html-template').innerHTML;
                var originalContents = document.body.innerHTML;
                document.body.innerHTML = printContents;
                window.print();
                //document.body.innerHTML = originalContents;  
            });
        }
    };

})(jQuery);