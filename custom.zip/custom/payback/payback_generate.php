<?php

require_once('../nusoap.php');
$server = new nusoap_server();
$server->configureWSDL('ws_stringurl', 'urn:ws_stringurl');

$server->register('payback_generate', array('url' => 'xsd:string'), array('status' => 'xsd:string'), 'urn:ws_stringurl', 'urn:ws_stringurl#payback_generate', 'rpc', 'literal', 'BBD'
);

/**
 * 
 * @param type $param
 * @return type
 */
function payback_generate($url) {
  $path = $_SERVER['DOCUMENT_ROOT'];
  chdir($path);
  define('DRUPAL_ROOT', rtrim(getcwd(), 'payback')); //the most important line
  require_once DRUPAL_ROOT . '/includes/bootstrap.inc';
  drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);
 
  return 'SUCCESS';
}

$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);
?>