Step to integrate Multi Link Partner to BBOF 

1.  Auto Login Multilink Agent in Drupal Platform by click on button form Multilink Partner website to BBOF Drupal Website
    1.1     First we create a auto-login url using hook_menu. In page_callback we validate multilink user credentials.
    1.2     Ex :- middleware-dev.bigbazaardirect.com/partner-multilink?Data=yYHKXDW6UZUkhhwVBpWT7fJlewxmr+0UwPibVbgchgdfL8PDcStNoYoTs4bnOVUK
    1.3     In page_callback function , we validate encrypted query string using web service provided by Multink. If user is valid, we find the mapped drupal user against the given agent and login into BBOF Website.
    1.4     We create a new vocabulary called “partner-master” and add a new term called “multilink”
    1.5     There are two new field at User level, First field called “Agent Identifier”. this fields contain each unique id of Multink User . Using this field we mapped drupal users with multink agents.
    1.6     Second Field is a Taxonomy Term Called “partner-master-taxonomy” which shows User belong to which partner Ex : Multilink, Ap-online .
    1.7     Partner will be login as Normal drupal user, using userid and password.


2.  After successful login redirect to /partner-name page
    2.1    Ex: If any multilink user login successfully, we have to redirect to 
           bbof_website/multilink page, where we display home page.
    2.2    for this redirection, we make change in bbd_web module.
    2.3    We create a alias as same as term name where user will redirect.

3.  Enable and Disable Partner and Agent Use
    3.1    There is a field called “On/Off partner Flag” at taxonomy level.
    3.2    Example : if you want to disable all Multilink User. Go to Multilink taxonomy 
           and uncheck the On/Off partner Flag, so all Multilink agent plus partner 
           user will be disable.
    3.3    For Enable Users, do the vice-versa.
        
4.  Display partner logo and BBOF Powered by LOGO
    4.1    Once partner agent login in BBOF, we display corresponding partner logo with 
           bbof powered logo.
    4.2    There is a field called “Partner Logo” at taxonomy level, where we add 
           an image for every partner.
    4.3    Example : If any any multilink user login in bbof site. We use hook_preprocess
           function, in this function we check whether for login user belong to one of our 
           partners , then we return image url else return empty.
    4.4    and we store the image value in variable and render this variable in page.tpl.php
    
     
5.  Disable Franchise code on customer code 
    5.1    We call check_franchise_is_partner_using_uid() function which check current login
           user is belong to one of our partners or not.
    5.2    if user is belong to partner , we are not displaying franchise code box 
           else it will visible to normal franchise.
    5.3    change in bbd.common module

6.  By Default “Billing Address is Selected” checkbox is checked on customer-shipping page.
    6.1    same logic as applied in point 5.1
    6.2    we render form billing address form if user is one of our partner else not.

7.  Display Multilink wallet payment method and redirect
    7.1    we display multilink wallet method for Multilink users only.
    7.2    To display a Multilink Wallet method for Multilink, we make following db changes
           first add term called “Multilink ” in “payment_combination” vocabulary
           also add term called “Multilink ” in “payment_methods” vocabulary.
    7.3    We also display a Payment Method on order display, which shows
           from field at order level called “Payment Mode”
    7.4    after click on proceed to payment button, user will redirect to Multilink 3D wallet 
           payment gateway with parameter such as order_id, date, price etc..
    7.5    where agent will fill login credentials and redirect to our own custom return url.
           return url example  :- $base_url . '/payment-return-url/' . $order_id . '/multilink'
    7.6    in that return url we get response from multilink gateway, based on this we 
           validate with our end and call various web service of multilink such as verification
           and confirmation api call once the order is confirmed.
    7.7    Once order is confirmed, we send order placed message on billing address
           mobile number and email id.
    7.8    we maintain payment log table for every callback of multilink web service in 
           “multilink_payment_log” table.

8.  Save Agent Commision at Line Item Level
    8.1    We maintain agent commision in percentage value at taxonomy level.
    8.2    We create a field called “Agent Commission” at taxonomy level.
    8.3    For each partner term, we save agent commission in percentage.
    8.4    Example : For Multilink , agent commission was 80 and partner commission is 20
           we save 80 in Agent Commision field at “multilink” term.
    8.5    When multilink agent place the order, after order confirmation, we get the value 
           form “Agent Commission” field of “Multilink” and store in field called 
           “alliance agent commision”            
                                                            
9.  Add Channel for Multilink Orders
    9.1    We maintain channel, to check whether order is placed from Multilink Agent
    9.2    For this, Once order is placed successfully, in the end we update two fields at
           order level namely field_order_channel, in this we store value from another 
           field at order level called “Order Channel” also we update another order 
           level field Order placed using as “Website_Multilink”. 
         
10. Partner Login and Its mapping with respective Term
    10.1    Partner will login as normal drupal user login via entering username 
        and password in BBOF site.
    10.2    For Partner user mapping with respective partner term, we maintain 
        field at taxonomy level called “partner User ref” in this field we
        store uid of partner user for respective partner term. 


For More Info about Multilink Login credentials, db changes, Dependent Modules follow the below Reference Sheet :- 
https://docs.google.com/a/iksula.com/spreadsheets/d/1j4EiCZBZpkkbZDzrrDqAC1yZwPIyK04EC2q4JFaf1Cg/edit?usp=sharing
