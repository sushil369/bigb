<form id ="multilink_payment_form" method="POST" action="http://www.mbznssol.biz/">
    <input type="hidden" name="MerchantId" value="<?php echo $_GET['MerchantID'] ?>" />
    <input type="hidden" name="OrderId" value="<?php echo $_GET['OrderID'] ?>" />
    <input type="hidden" name="OfferPrice" value="<?php echo $_GET['Offerprice'] ?>" />
    <input type="hidden" name="Date" value="<?php echo $_GET['Date'] ?>" />
    <input type="hidden" name="Product" value="<?php echo $_GET['Product'] ?>" />
    <input type="hidden" name="PublishedPrice" value="<?php echo $_GET['PublishedPrice'] ?>" />
    <input type="hidden" name="Mode" value="<?php echo $_GET['Mode'] ?>" />
    <input type="hidden" name="ReturnURL" value="<?php echo $_GET['ReturnURL'] ?>" />
    <input type="hidden" name="CustomerName" value="<?php echo $_GET['CustomerName'] ?>" />
    <input type="hidden" name="Description" value="<?php echo $_GET['Description'] ?>" />
    <input type="hidden" name="TDS" value="<?php echo $_GET['TDS'] ?>" />
    <input type="hidden" name="AgentLogin" value="<?php echo $_GET['AgentLogin'] ?>" />
</form>
<script type="text/javascript">
  document.getElementById('multilink_payment_form').submit();
</script>